import { useState, useEffect } from 'react';
import {
  Upload,
  Database,
  AlertCircle,
  FileCheck2,
} from 'lucide-react';
import { Sidebar, Header, ActiveTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { DataOverviewView } from './components/DataOverviewView';
import { SalesAnalysisView } from './components/SalesAnalysisView';
import { CustomerSegmentationView } from './components/CustomerSegmentationView';
import { AssociationView } from './components/AssociationView';
import { TemporalAssociationView } from './components/TemporalAssociationView';
import { PredictiveView } from './components/PredictiveView';
import { BusinessInsightsView } from './components/BusinessInsightsView';

import {
  PreparedData,
  RFMAnalysisResult,
  AssociationAnalysisResult,
  TemporalAssociationResult,
  PredictiveAnalysisState,
  MLModelResult,
} from './types';

import { parseCsvContent } from './engine/dataParser';
import { computeSalesAnalysis, SalesAnalysisResult } from './engine/salesAnalysis';
import { buildRFMAnalysis } from './engine/rfmSegmentation';
import { computeAssociationAnalysis, computeTemporalAssociationMining } from './engine/associationMining';
import {
  buildMLDataset,
  makeTimeSplit,
  computeMutualInformation,
  trainModel,
  createPredictionOutputs,
  MLRow,
} from './engine/predictiveEngine';
import { generateBenchmarkRetailCsv } from './data/retailSample';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [preparedData, setPreparedData] = useState<PreparedData | null>(null);
  const [salesAnalysis, setSalesAnalysis] = useState<SalesAnalysisResult | null>(null);

  // Computational states
  const [rfmResult, setRfmResult] = useState<RFMAnalysisResult | null>(null);
  const [isRfmRunning, setIsRfmRunning] = useState<boolean>(false);

  const [assocResult, setAssocResult] = useState<AssociationAnalysisResult | null>(null);
  const [isAssocRunning, setIsAssocRunning] = useState<boolean>(false);

  const [temporalResult, setTemporalResult] = useState<TemporalAssociationResult | null>(null);
  const [isTemporalRunning, setIsTemporalRunning] = useState<boolean>(false);

  const [predictiveState, setPredictiveState] = useState<PredictiveAnalysisState | null>(null);
  const [mlDataInternal, setMlDataInternal] = useState<{
    trainRows: MLRow[];
    testRows: MLRow[];
    productDescriptions: Map<string, string>;
  } | null>(null);
  const [isMlPreparing, setIsMlPreparing] = useState<boolean>(false);
  const [isTraining, setIsTraining] = useState<boolean>(false);

  // Navigation & Drawer
  const [isMobileOpen, setIsMobileOpen] = useState<boolean>(false);

  // Global loading and error
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Process raw CSV string into prepared datasets
  const processCsv = (csvText: string) => {
    try {
      setIsLoading(true);
      setLoadingMessage('Validating schema and parsing transactions...');
      setErrorMessage(null);

      const parsed = parseCsvContent(csvText);
      setPreparedData(parsed);

      setLoadingMessage('Computing sales analytics and geographic breakdowns...');
      const sales = computeSalesAnalysis(parsed.salesRows);
      setSalesAnalysis(sales);

      // Reset subsequent analysis caches
      setRfmResult(null);
      setAssocResult(null);
      setTemporalResult(null);
      setPredictiveState(null);
      setMlDataInternal(null);

      // Pre-compute RFM and ML preparation seamlessly in the background
      setTimeout(() => {
        try {
          if (parsed.customerRows.length > 0) {
            const rfm = buildRFMAnalysis(parsed.customerRows, 2);
            setRfmResult(rfm);
          }
          prepareMLDataset(parsed);
        } catch {
          // Gracefully continue
        }
      }, 50);
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred during CSV parsing.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleFileUpload = (file: File) => {
    setIsLoading(true);
    setLoadingMessage('Reading uploaded file payload...');
    setErrorMessage(null);

    const reader = new FileReader();

    reader.onload = e => {
      const text = e.target?.result as string;
      if (text) {
        processCsv(text);
      } else {
        setIsLoading(false);
        setErrorMessage('Uploaded file is empty.');
      }
    };

    reader.onerror = () => {
      // Fallback with latin1 encoding
      const fallbackReader = new FileReader();
      fallbackReader.onload = fe => {
        const fText = fe.target?.result as string;
        if (fText) {
          processCsv(fText);
        } else {
          setIsLoading(false);
          setErrorMessage('Failed to read file contents.');
        }
      };
      fallbackReader.onerror = () => {
        setIsLoading(false);
        setErrorMessage('File read error. Please ensure the file is a valid CSV.');
      };
      fallbackReader.readAsText(file, 'latin1');
    };

    reader.readAsText(file, 'utf-8');
  };

  const handleLoadBenchmark = () => {
    setIsLoading(true);
    setLoadingMessage('Generating multi-month retail benchmark dataset...');
    setErrorMessage(null);

    setTimeout(() => {
      try {
        const csvText = generateBenchmarkRetailCsv();
        processCsv(csvText);
      } catch (err: any) {
        setIsLoading(false);
        setErrorMessage(err.message || 'Failed to generate benchmark dataset.');
      }
    }, 100);
  };

  // Re-run analytics pipeline from currently ingested data
  const handleRefresh = () => {
    if (!preparedData) return;
    setIsLoading(true);
    setLoadingMessage('Refreshing analysis calculations...');
    setTimeout(() => {
      try {
        const sales = computeSalesAnalysis(preparedData.salesRows);
        setSalesAnalysis(sales);
        if (preparedData.customerRows.length > 0) {
          const rfm = buildRFMAnalysis(preparedData.customerRows, 2);
          setRfmResult(rfm);
        }
        prepareMLDataset(preparedData);
      } catch (err: any) {
        setErrorMessage(`Refresh error: ${err.message}`);
      } finally {
        setIsLoading(false);
        setLoadingMessage('');
      }
    }, 50);
  };

  // Run RFM Segmentation
  const handleRunRFM = () => {
    if (!preparedData) return;
    setIsRfmRunning(true);
    setTimeout(() => {
      try {
        const res = buildRFMAnalysis(preparedData.customerRows, 2);
        setRfmResult(res);
      } catch (err: any) {
        setErrorMessage(`RFM Error: ${err.message}`);
      } finally {
        setIsRfmRunning(false);
      }
    }, 30);
  };

  // Run Association Mining
  const handleRunAssociation = () => {
    if (!preparedData) return;
    setIsAssocRunning(true);
    setTimeout(() => {
      try {
        const res = computeAssociationAnalysis(preparedData.basketRows);
        setAssocResult(res);
      } catch (err: any) {
        setErrorMessage(`Association Mining Error: ${err.message}`);
      } finally {
        setIsAssocRunning(false);
      }
    }, 30);
  };

  // Run Temporal Mining
  const handleRunTemporal = () => {
    if (!preparedData) return;
    setIsTemporalRunning(true);
    setTimeout(() => {
      try {
        const res = computeTemporalAssociationMining(preparedData.basketRows);
        setTemporalResult(res);
      } catch (err: any) {
        setErrorMessage(`Temporal Mining Error: ${err.message}`);
      } finally {
        setIsTemporalRunning(false);
      }
    }, 30);
  };

  // Prepare ML Dataset
  const prepareMLDataset = (data: PreparedData) => {
    setIsMlPreparing(true);
    try {
      const { modelRows, productDescriptions } = buildMLDataset(data.salesRows);
      if (modelRows.length === 0) {
        setErrorMessage('Insufficient continuous monthly data to generate time-series lag features.');
        return;
      }

      const { trainRows, testRows, trainPeriod, testPeriod } = makeTimeSplit(modelRows);

      let count0 = 0;
      let count1 = 0;
      for (const r of trainRows) {
        if (r.Target === 1) count1++;
        else count0++;
      }
      const totalTrain = trainRows.length || 1;

      const trainClassDist = [
        { Target: 0, Count: count0, Percentage: Math.round((count0 / totalTrain) * 10000) / 100 },
        { Target: 1, Count: count1, Percentage: Math.round((count1 / totalTrain) * 10000) / 100 },
      ];

      setMlDataInternal({ trainRows, testRows, productDescriptions });

      setPredictiveState({
        trainRowsCount: trainRows.length,
        testRowsCount: testRows.length,
        trainPeriod,
        testPeriod,
        trainClassDist,
        featureCount: 15,
        results: {},
        activeModel: 'Random Forest',
        predictions: [],
      });
    } catch (err: any) {
      setErrorMessage(`ML Prep Error: ${err.message}`);
    } finally {
      setIsMlPreparing(false);
    }
  };

  // Train selected or all models
  const handleTrainModel = (modelName: string, compareAll: boolean) => {
    if (!mlDataInternal || !predictiveState) {
      if (preparedData) {
        prepareMLDataset(preparedData);
      }
      return;
    }

    setIsTraining(true);
    setTimeout(() => {
      try {
        const { trainRows, testRows, productDescriptions } = mlDataInternal;
        const { selectedColumns, featureScores } = computeMutualInformation(trainRows, 10);

        const modelsToTrain = compareAll ? ['Logistic Regression', 'Random Forest', 'XGBoost'] : [modelName];

        const newResults: Record<string, MLModelResult> = { ...predictiveState.results };

        let primaryModelPredictions: number[] = [];
        let primaryModelProbs: number[] = [];

        for (const mName of modelsToTrain) {
          const res = trainModel(mName, trainRows, testRows, selectedColumns);

          let predBestSellerCount = 0;
          for (const p of res.predictions) {
            if (p === 1) predBestSellerCount++;
          }

          // Check if test single class
          let testClass0 = 0;
          let testClass1 = 0;
          for (const r of testRows) {
            if (r.Target === 1) testClass1++;
            else testClass0++;
          }
          const testSingleClass = testClass0 === 0 || testClass1 === 0;

          newResults[mName] = {
            modelName: mName,
            accuracy: res.accuracy,
            trainTimeSeconds: res.trainTimeSeconds,
            selectedColumns,
            featureScores,
            confusionMatrix: res.confusionMatrix,
            testSingleClass,
            predictionsCount: res.predictions.length,
            predictedBestSellerCount: predBestSellerCount,
          };

          if (mName === modelName || (!compareAll && modelsToTrain.length === 1)) {
            primaryModelPredictions = res.predictions;
            primaryModelProbs = res.probabilities;
          }
        }

        const activeName = modelName;
        const chosenPredictions = primaryModelPredictions.length > 0 ? primaryModelPredictions : [];
        const chosenProbs = primaryModelProbs.length > 0 ? primaryModelProbs : [];

        const predictionOutputs = createPredictionOutputs(
          testRows,
          chosenPredictions,
          chosenProbs,
          productDescriptions
        );

        setPredictiveState({
          ...predictiveState,
          results: newResults,
          activeModel: activeName,
          predictions: predictionOutputs,
        });
      } catch (err: any) {
        setErrorMessage(`Model Training Error: ${err.message}`);
      } finally {
        setIsTraining(false);
      }
    }, 50);
  };

  // Auto-load benchmark on first startup so the app is instantly rich and operational
  useEffect(() => {
    if (!preparedData && !isLoading) {
      handleLoadBenchmark();
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#F7FAFC] text-[#243447] flex font-sans antialiased">
      {/* Modern Pastel Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        quality={preparedData?.quality || null}
        onFileUpload={handleFileUpload}
        onLoadBenchmark={handleLoadBenchmark}
        isLoading={isLoading}
        isOpenMobile={isMobileOpen}
        onCloseMobile={() => setIsMobileOpen(false)}
      />

      {/* Main Content Pane */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top Header */}
        <Header
          onOpenMobile={() => setIsMobileOpen(true)}
          quality={preparedData?.quality || null}
          onRefresh={handleRefresh}
          isLoading={isLoading}
        />

        {/* Global Error Alert Banner in Soft Coral */}
        {errorMessage && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 w-full">
            <div className="p-4 bg-[#FFF0F1] border border-[#F4CDD0] rounded-2xl text-xs text-[#A84D55] flex items-start justify-between gap-3 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-[#E58B91] flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold block mb-0.5">Pipeline Validation / Execution Alert:</strong>
                  {errorMessage}
                </div>
              </div>
              <button
                onClick={() => setErrorMessage(null)}
                className="text-[#A84D55] hover:text-[#243447] font-bold px-1.5 cursor-pointer"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Dynamic Page Views */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {isLoading ? (
            <div className="bg-white border border-[#E7ECF2] rounded-2xl p-16 text-center shadow-[0_4px_16px_rgba(30,60,90,0.04)] space-y-4">
              <div className="w-10 h-10 border-4 border-[#5B9FE8] border-t-transparent rounded-full animate-spin mx-auto" />
              <div className="text-base font-semibold text-[#243447]">
                {loadingMessage || 'Computing retail data pipeline...'}
              </div>
              <p className="text-xs text-[#667085] max-w-md mx-auto">
                Executing real data validation, preprocessing, and statistical aggregation. No hard-coded values used.
              </p>
            </div>
          ) : !preparedData || !salesAnalysis ? (
            <div className="bg-white border border-[#E7ECF2] rounded-2xl p-10 sm:p-14 text-center shadow-[0_4px_16px_rgba(30,60,90,0.04)] space-y-6 max-w-3xl mx-auto my-8">
              <div className="w-14 h-14 bg-[#EAF4FF] border border-[#CFE5FA] rounded-2xl flex items-center justify-center mx-auto text-[#5B9FE8]">
                <Upload className="w-7 h-7" />
              </div>

              <div>
                <h1 className="text-2xl font-bold text-[#243447] tracking-tight">Smart Retail Analytics System</h1>
                <p className="text-sm text-[#667085] mt-2 max-w-lg mx-auto">
                  Comprehensive data mining engine reproducing RFM customer segmentation, Apriori &amp; FP-Growth association rules, and best-seller ML classification.
                </p>
              </div>

              <div className="bg-[#F7FAFC] border border-[#E7ECF2] rounded-xl p-4 text-left text-xs max-w-lg mx-auto space-y-2">
                <div className="font-semibold text-[#243447] flex items-center gap-1.5">
                  <FileCheck2 className="w-4 h-4 text-[#5B9FE8]" />
                  Required CSV Schema Columns:
                </div>
                <p className="text-[#667085] font-mono text-[11px] leading-relaxed">
                  InvoiceNo, StockCode, Description, Quantity, InvoiceDate, UnitPrice, CustomerID, Country
                </p>
                <div className="text-[11px] text-[#98A2B3] pt-1 border-t border-[#E7ECF2]">
                  Encodings supported: UTF-8 with automatic Latin-1 fallback. Missing CustomerID excluded from RFM; cancelled invoices (prefix &apos;C&apos;) filtered out.
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <label
                  htmlFor="initial-upload-input"
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#5B9FE8] hover:bg-[#4a8fd9] text-white text-xs font-semibold shadow-sm transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  Upload Retail CSV File
                  <input
                    type="file"
                    id="initial-upload-input"
                    accept=".csv"
                    onChange={e => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(e.target.files[0]);
                      }
                    }}
                    className="hidden"
                  />
                </label>

                <button
                  onClick={handleLoadBenchmark}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#F1F7FD] hover:bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA] text-xs font-semibold shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Database className="w-4 h-4 text-[#5B9FE8]" />
                  Load 10-Month Benchmark Sample
                </button>
              </div>
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && (
                <DashboardView data={preparedData} salesAnalysis={salesAnalysis} />
              )}

              {activeTab === 'data-overview' && (
                <DataOverviewView data={preparedData} />
              )}

              {activeTab === 'sales-analysis' && (
                <SalesAnalysisView salesAnalysis={salesAnalysis} />
              )}

              {activeTab === 'customer-segmentation' && (
                <CustomerSegmentationView
                  rfmResult={rfmResult}
                  onRunRFM={handleRunRFM}
                  isRunning={isRfmRunning}
                  totalCustomers={preparedData.quality.uniqueCustomers}
                />
              )}

              {activeTab === 'association-analysis' && (
                <AssociationView
                  assocResult={assocResult}
                  onRunAssociation={handleRunAssociation}
                  isAssocRunning={isAssocRunning}
                  basketTransactionsCount={preparedData.quality.validTransactions}
                  distinctProductsCount={salesAnalysis.topProductsQuantity.length}
                />
              )}

              {activeTab === 'temporal-analysis' && (
                <TemporalAssociationView
                  temporalResult={temporalResult}
                  onRunTemporal={handleRunTemporal}
                  isRunning={isTemporalRunning}
                  basketTransactionsCount={preparedData.quality.validTransactions}
                />
              )}

              {activeTab === 'predictive-analysis' && (
                <PredictiveView
                  predictiveState={predictiveState}
                  onTrainModel={handleTrainModel}
                  isTraining={isTraining}
                  onPrepareML={() => prepareMLDataset(preparedData)}
                  isPreparing={isMlPreparing}
                />
              )}

              {activeTab === 'business-insights' && (
                <BusinessInsightsView
                  rfmResult={rfmResult}
                  assocResult={assocResult}
                  predictiveState={predictiveState}
                />
              )}
            </>
          )}
        </main>

        {/* Fresh Pastel Light Footer */}
        <footer className="border-t border-[#E7ECF2] bg-white py-4 text-center text-xs text-[#667085] mt-auto">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-[#243447]">Smart Retail Analytics System</span>
              <span>&bull;</span>
              <span className="text-[#287A50] font-medium">100% Real Analytical Execution</span>
            </div>
            <div className="flex items-center gap-3 text-[#98A2B3]">
              <span>RFM Standard (FINAL_K=2)</span>
              <span>&bull;</span>
              <span>Apriori &amp; FP-Growth</span>
              <span>&bull;</span>
              <span>Mutual Info ML</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
