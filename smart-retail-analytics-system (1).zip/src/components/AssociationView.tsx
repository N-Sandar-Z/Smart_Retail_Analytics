import React from 'react';
import { Play, GitFork, ArrowRight, Zap, CheckCircle2, ShoppingCart, Layers } from 'lucide-react';
import { AssociationAnalysisResult } from '../types';

interface AssociationViewProps {
  assocResult: AssociationAnalysisResult | null;
  onRunAssociation: () => void;
  isAssocRunning: boolean;
  basketTransactionsCount: number;
  distinctProductsCount: number;
}

export const AssociationView: React.FC<AssociationViewProps> = ({
  assocResult,
  onRunAssociation,
  isAssocRunning,
  basketTransactionsCount,
  distinctProductsCount,
}) => {
  const aprioriComp = assocResult?.comparison.find(c => c.Algorithm.includes('Apriori'));
  const fpComp = assocResult?.comparison.find(c => c.Algorithm.includes('FP-Growth'));

  const speedup =
    aprioriComp && fpComp && fpComp.executionTimeSeconds > 0
      ? (aprioriComp.executionTimeSeconds / fpComp.executionTimeSeconds).toFixed(1)
      : '1.0';

  return (
    <div className="space-y-6">
      {/* View Header with Soft Peach Accent */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-gradient-to-r from-[#FFF1E5] to-white p-6 rounded-2xl border border-[#F6D6BC] shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#F6D6BC] text-[#A55D25]">
              Affinity &amp; Bundle Mining
            </span>
            <span className="text-xs text-[#667085]">• Apriori &amp; FP-Growth Algorithmic Parity</span>
          </div>
          <h2 className="text-xl font-bold text-[#243447] tracking-tight">Market Basket Association Analysis</h2>
          <p className="text-xs text-[#667085] mt-1 max-w-2xl">
            Frequent itemset mining discovering multi-product affinities, cross-sell pairings, and algorithmic execution benchmarks between candidate generation and prefix tree structures.
          </p>
        </div>

        <button
          id="run-mining-btn"
          onClick={onRunAssociation}
          disabled={isAssocRunning || basketTransactionsCount === 0}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#E9A66B] hover:bg-[#d89355] text-white font-medium text-xs shadow-[0_2px_8px_rgba(233,166,107,0.3)] transition disabled:opacity-50 cursor-pointer whitespace-nowrap"
        >
          {isAssocRunning ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Mining Frequent Itemsets...
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              Run Market Basket Mining
            </>
          )}
        </button>
      </div>

      {/* Dataset & Parameter Banners in Peach/Pastel Tints */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-b from-[#FFF1E5]/80 to-white border border-[#F6D6BC] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#A55D25]">Active Baskets</span>
            <div className="w-8 h-8 rounded-xl bg-[#FFF1E5] flex items-center justify-center text-[#E9A66B] border border-[#F6D6BC]">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {basketTransactionsCount.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Multi-item validated customer baskets</div>
        </div>

        <div className="bg-gradient-to-b from-[#EAF4FF]/80 to-white border border-[#CFE5FA] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2867A8]">Catalog Items</span>
            <div className="w-8 h-8 rounded-xl bg-[#EAF4FF] flex items-center justify-center text-[#5B9FE8] border border-[#CFE5FA]">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {distinctProductsCount.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Unique merchandise SKUs evaluated</div>
        </div>

        <div className="bg-gradient-to-b from-[#EAF8F0]/80 to-white border border-[#CBEBD9] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#287A50]">Mining Hyperparameters</span>
            <div className="w-8 h-8 rounded-xl bg-[#EAF8F0] flex items-center justify-center text-[#62B88A] border border-[#CBEBD9]">
              <GitFork className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-xl font-bold text-[#287A50] font-mono">
            min_sup: 2% &bull; min_conf: 30%
          </div>
          <div className="mt-1 text-xs text-[#667085]">Project standard thresholds applied</div>
        </div>
      </div>

      {assocResult ? (
        <>
          {/* Algorithmic Parity Benchmark Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Apriori */}
            <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#667085]">Apriori Algorithm</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#F1F7FD] text-[#2867A8] border border-[#CFE5FA]">
                  Candidate Gen
                </span>
              </div>
              <div className="mt-3">
                <div className="text-3xl font-bold text-[#243447] font-mono">
                  {aprioriComp ? `${aprioriComp.executionTimeSeconds.toFixed(3)}s` : '—'}
                </div>
                <div className="mt-1 text-xs text-[#667085]">
                  Generated <strong>{aprioriComp?.frequentItemsetsCount.toLocaleString() ?? 0}</strong> frequent itemsets
                </div>
              </div>
            </div>

            {/* FP-Growth */}
            <div className="bg-gradient-to-b from-[#FFF1E5]/80 to-white border border-[#F6D6BC] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#A55D25]">FP-Growth Algorithm</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FFF1E5] text-[#A55D25] border border-[#F6D6BC]">
                  Prefix Tree
                </span>
              </div>
              <div className="mt-3">
                <div className="text-3xl font-bold text-[#A55D25] font-mono">
                  {fpComp ? `${fpComp.executionTimeSeconds.toFixed(3)}s` : '—'}
                </div>
                <div className="mt-1 text-xs text-[#667085]">
                  Generated <strong>{fpComp?.frequentItemsetsCount.toLocaleString() ?? 0}</strong> frequent itemsets
                </div>
              </div>
            </div>

            {/* Speedup Comparison */}
            <div className="bg-gradient-to-b from-[#EAF8F0]/80 to-white border border-[#CBEBD9] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#287A50]">Runtime Speedup</span>
                <div className="w-8 h-8 rounded-xl bg-[#EAF8F0] flex items-center justify-center text-[#62B88A]">
                  <Zap className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3">
                <div className="text-3xl font-bold text-[#287A50] font-mono">
                  {speedup}x Faster
                </div>
                <div className="mt-1 text-xs text-[#287A50] font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Both algorithms yield 100% equivalent rules
                </div>
              </div>
            </div>
          </div>

          {/* Association Rules Table */}
          <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">
                  Discovered Association Rules ({assocResult.filteredRules.length} Total Rules)
                </h3>
                <p className="text-xs text-[#667085]">
                  Ranked by Lift (ratio of joint occurrence to independent expectation)
                </p>
              </div>
              <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#FFF1E5] text-[#A55D25] border border-[#F6D6BC]">
                Sorted by Lift &darr;
              </span>
            </div>

            {assocResult.filteredRules.length > 0 ? (
              <div className="overflow-x-auto max-h-96 rounded-xl border border-[#E7ECF2]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
                    <tr>
                      <th className="py-2.5 px-3 font-semibold">#</th>
                      <th className="py-2.5 px-3 font-semibold">Antecedents (Customer Buys...)</th>
                      <th className="py-2.5 px-3 font-semibold text-center">Affinity</th>
                      <th className="py-2.5 px-3 font-semibold">Consequents (...Also Buys)</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Support</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Confidence</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Lift Ratio</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E7ECF2] font-mono">
                    {assocResult.filteredRules.map((rule, idx) => (
                      <tr key={idx} className="hover:bg-[#F9FBFC] transition-colors">
                        <td className="py-2 px-3 text-[#98A2B3]">
                          <span className="w-5 h-5 rounded-full bg-[#F1F7FD] text-[#2867A8] inline-flex items-center justify-center text-[10px] font-bold">
                            {idx + 1}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-sans font-medium text-[#243447] max-w-xs truncate" title={rule.Antecedent}>
                          {rule.Antecedent}
                        </td>
                        <td className="py-2 px-3 text-center">
                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#FFF1E5] text-[#A55D25]">
                            <ArrowRight className="w-3 h-3" />
                          </span>
                        </td>
                        <td className="py-2 px-3 font-sans font-medium text-[#A55D25] max-w-xs truncate" title={rule.Consequent}>
                          {rule.Consequent}
                        </td>
                        <td className="py-2 px-3 text-right text-[#667085]">
                          {(rule.support * 100).toFixed(2)}%
                        </td>
                        <td className="py-2 px-3 text-right text-[#667085]">
                          {(rule.confidence * 100).toFixed(1)}%
                        </td>
                        <td className="py-2 px-3 text-right font-bold text-[#287A50]">
                          <span className="px-2 py-0.5 rounded-md bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                            {rule.lift.toFixed(2)}x
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-8 bg-[#F7FAFC] border border-[#E7ECF2] rounded-xl text-center text-xs text-[#667085]">
                No association rules met the support (&ge; 2%) and confidence (&ge; 30%) filters.
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-12 text-center shadow-[0_4px_16px_rgba(30,60,90,0.03)] space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#FFF1E5] border border-[#F6D6BC] flex items-center justify-center mx-auto text-[#E9A66B]">
            <GitFork className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#243447]">Market Basket Mining Uncalculated</h3>
            <p className="text-xs text-[#667085] mt-1 max-w-md mx-auto">
              Execute Apriori and FP-Growth algorithms on customer shopping baskets to discover cross-selling bundles and compare execution speeds.
            </p>
          </div>
          <button
            onClick={onRunAssociation}
            disabled={isAssocRunning || basketTransactionsCount === 0}
            className="px-5 py-2.5 rounded-xl bg-[#E9A66B] hover:bg-[#d89355] text-white font-semibold text-xs shadow-sm transition disabled:opacity-50 cursor-pointer"
          >
            Compute Apriori &amp; FP-Growth Rules
          </button>
        </div>
      )}
    </div>
  );
};
