import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { Play, Sparkles, Users, Award, ShieldCheck } from 'lucide-react';
import { RFMAnalysisResult } from '../types';

interface CustomerSegmentationViewProps {
  rfmResult: RFMAnalysisResult | null;
  onRunRFM: () => void;
  isRunning: boolean;
  totalCustomers: number;
}

export const CustomerSegmentationView: React.FC<CustomerSegmentationViewProps> = ({
  rfmResult,
  onRunRFM,
  isRunning,
  totalCustomers,
}) => {
  return (
    <div className="space-y-6">
      {/* View Header with Soft Purple Accent */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-gradient-to-r from-[#F3EEFF] to-white p-6 rounded-2xl border border-[#DDD1F7] shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#DDD1F7] text-[#6548A5]">
              Customer Intelligence
            </span>
            <span className="text-xs text-[#667085]">• StandardScaler + K-Means</span>
          </div>
          <h2 className="text-xl font-bold text-[#243447] tracking-tight">Customer RFM &amp; K-Means Clustering</h2>
          <p className="text-xs text-[#667085] mt-1 max-w-2xl">
            Recency, Frequency, and Monetary valuation modeling with K=2..8 Silhouette evaluation and behavioural segment profiling.
          </p>
        </div>
        <button
          id="run-rfm-btn"
          onClick={onRunRFM}
          disabled={isRunning || totalCustomers === 0}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#9B82D6] hover:bg-[#896ec8] text-white font-medium text-xs shadow-[0_2px_8px_rgba(155,130,214,0.3)] transition disabled:opacity-50 cursor-pointer whitespace-nowrap"
        >
          {isRunning ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Computing RFM &amp; K-Means...
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              Run RFM + K-Means
            </>
          )}
        </button>
      </div>

      {rfmResult ? (
        <>
          {/* Top Metric Cards in Purple / Green / Blue */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-gradient-to-b from-[#F3EEFF]/80 to-white border border-[#DDD1F7] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#6548A5]">Recommended K</span>
                <div className="w-8 h-8 rounded-xl bg-[#F3EEFF] flex items-center justify-center text-[#9B82D6] border border-[#DDD1F7]">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 text-3xl font-bold text-[#6548A5] font-mono">
                K = {rfmResult.recommendedK}
              </div>
              <div className="mt-1 text-xs text-[#667085]">
                Optimal cluster partition by highest silhouette score
              </div>
            </div>

            <div className="bg-gradient-to-b from-[#EAF8F0]/80 to-white border border-[#CBEBD9] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#287A50]">Specification K Used</span>
                <div className="w-8 h-8 rounded-xl bg-[#EAF8F0] flex items-center justify-center text-[#62B88A] border border-[#CBEBD9]">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 text-3xl font-bold text-[#287A50] font-mono">
                FINAL_K = {rfmResult.finalK}
              </div>
              <div className="mt-1 text-xs text-[#667085]">
                Preserved project requirement standard (FINAL_K = 2)
              </div>
            </div>

            <div className="bg-gradient-to-b from-[#EAF4FF]/80 to-white border border-[#CFE5FA] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#2867A8]">Segmented Customers</span>
                <div className="w-8 h-8 rounded-xl bg-[#EAF4FF] flex items-center justify-center text-[#5B9FE8] border border-[#CFE5FA]">
                  <Users className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
                {rfmResult.rfm.length.toLocaleString()}
              </div>
              <div className="mt-1 text-xs text-[#667085]">
                Unique customer IDs with valid purchase activity
              </div>
            </div>
          </div>

          {/* K-Evaluation Table & Silhouette Curve */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-sm font-semibold text-[#243447]">K-Means Evaluation (K = 2 to 8)</h3>
                  <p className="text-xs text-[#667085]">Inertia (SSE) and Silhouette metrics across candidate K</p>
                </div>
                <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#F3EEFF] text-[#6548A5] border border-[#DDD1F7]">
                  Evaluations
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-[#E7ECF2]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2]">
                    <tr>
                      <th className="py-2.5 px-3 font-semibold">K</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Inertia (SSE)</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Silhouette Score</th>
                      <th className="py-2.5 px-3 font-semibold text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E7ECF2] font-mono">
                    {rfmResult.kEval.map(row => (
                      <tr key={row.K} className="hover:bg-[#F9FBFC] transition-colors">
                        <td className="py-2 px-3 font-bold text-[#243447]">K = {row.K}</td>
                        <td className="py-2 px-3 text-right text-[#667085]">{row.Inertia.toLocaleString()}</td>
                        <td className="py-2 px-3 text-right text-[#6548A5] font-bold">{row.Silhouette.toFixed(4)}</td>
                        <td className="py-2 px-3 text-center">
                          {row.K === rfmResult.recommendedK && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#F3EEFF] text-[#6548A5] border border-[#DDD1F7]">
                              <Sparkles className="w-2.5 h-2.5" /> Best
                            </span>
                          )}
                          {row.K === rfmResult.finalK && (
                            <span className="inline-flex items-center ml-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                              Final K
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="lg:col-span-6 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-sm font-semibold text-[#243447]">Silhouette Score Evaluation Curve</h3>
                  <p className="text-xs text-[#667085]">Cluster cohesion vs. inter-cluster separation</p>
                </div>
                <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                  Cohesion Curve
                </span>
              </div>
              <div className="h-60 w-full flex-1">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={rfmResult.kEval} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F0F4F8" />
                    <XAxis dataKey="K" tick={{ fontSize: 11, fill: '#667085' }} label={{ value: 'Number of Clusters (K)', position: 'insideBottom', offset: -5, fontSize: 11, fill: '#667085' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#667085' }} domain={['auto', 'auto']} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#FFFFFF',
                        borderColor: '#DDD1F7',
                        borderRadius: 12,
                        color: '#243447',
                        boxShadow: '0 4px 16px rgba(30, 60, 90, 0.08)',
                        fontSize: '12px',
                      }}
                    />
                    <Line type="monotone" dataKey="Silhouette" stroke="#9B82D6" strokeWidth={2.5} dot={{ r: 4, fill: '#9B82D6', stroke: '#FFFFFF', strokeWidth: 2 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Cluster Profile Table */}
          <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">Segment Profiles &amp; Targeted Business Actions</h3>
                <p className="text-xs text-[#667085]">
                  Behavioral characteristics mapped from standardized RFM cluster centroids.
                </p>
              </div>
              <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#FFF8DB] text-[#8A6812] border border-[#F5E6A8]">
                Cluster Playbook
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-[#E7ECF2]">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2]">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Cluster</th>
                    <th className="py-2.5 px-3 font-semibold">Segment Name</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Customers</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Share (%)</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Avg Recency</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Avg Frequency</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Avg Spend ($)</th>
                    <th className="py-2.5 px-3 font-semibold">Characteristics</th>
                    <th className="py-2.5 px-3 font-semibold">Business Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7ECF2]">
                  {rfmResult.clusterProfile.map(profile => (
                    <tr key={profile.Cluster} className="hover:bg-[#F9FBFC] transition-colors">
                      <td className="py-2.5 px-3 font-mono font-bold text-[#243447]">#{profile.Cluster}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                            profile.Segment.includes('VIP')
                              ? 'bg-[#FFF8DB] text-[#8A6812] border border-[#F5E6A8]'
                              : profile.Segment.includes('Regular')
                              ? 'bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA]'
                              : 'bg-[#FFF0F1] text-[#A84D55] border border-[#F4CDD0]'
                          }`}
                        >
                          {profile.Segment}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-[#243447]">
                        {profile.Customer_Count.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-[#667085]">
                        {profile.Customer_Percentage.toFixed(1)}%
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-[#667085]">{profile.Avg_Recency} days</td>
                      <td className="py-2.5 px-3 text-right font-mono text-[#667085]">{profile.Avg_Frequency} orders</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-[#287A50]">
                        ${profile.Avg_Monetary.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-3 text-[#243447] text-xs italic">{profile.Characteristics}</td>
                      <td className="py-2.5 px-3 text-[#6548A5] font-medium text-xs max-w-xs">{profile.BusinessAction}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Customer RFM Sample (First 50) */}
          <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">Customer Sample (First 50 Profiles)</h3>
                <p className="text-xs text-[#667085]">
                  Calculated customer RFM vectors and assigned segment groupings.
                </p>
              </div>
              <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#F3EEFF] text-[#6548A5] border border-[#DDD1F7]">
                Individual Vectors
              </span>
            </div>

            <div className="overflow-x-auto max-h-80 rounded-xl border border-[#E7ECF2]">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">CustomerID</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Recency (Days)</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Frequency (Orders)</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Monetary Spend ($)</th>
                    <th className="py-2.5 px-3 font-semibold text-center">Assigned Cluster</th>
                    <th className="py-2.5 px-3 font-semibold">Segment Group</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7ECF2] font-mono">
                  {rfmResult.rfm.slice(0, 50).map(c => (
                    <tr key={c.CustomerID} className="hover:bg-[#F9FBFC] transition-colors">
                      <td className="py-2 px-3 text-[#6548A5] font-semibold">{c.CustomerID}</td>
                      <td className="py-2 px-3 text-right text-[#667085]">{c.Recency}</td>
                      <td className="py-2 px-3 text-right text-[#667085]">{c.Frequency}</td>
                      <td className="py-2 px-3 text-right font-bold text-[#243447]">
                        ${c.Monetary.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-2 px-3 text-center text-[#243447] font-bold">#{c.Cluster}</td>
                      <td className="py-2 px-3 font-sans">
                        <span className="text-[11px] font-medium text-[#667085]">{c.Segment}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-12 text-center shadow-[0_4px_16px_rgba(30,60,90,0.03)] space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#F3EEFF] border border-[#DDD1F7] flex items-center justify-center mx-auto text-[#9B82D6]">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#243447]">Customer Segmentation Uncalculated</h3>
            <p className="text-xs text-[#667085] mt-1 max-w-md mx-auto">
              Compute customer Recency, Frequency, and Monetary metrics with StandardScaler and K-Means clustering.
            </p>
          </div>
          <button
            onClick={onRunRFM}
            disabled={isRunning || totalCustomers === 0}
            className="px-5 py-2.5 rounded-xl bg-[#9B82D6] hover:bg-[#896ec8] text-white font-semibold text-xs shadow-sm transition disabled:opacity-50 cursor-pointer"
          >
            Compute RFM &amp; K-Means Evaluation
          </button>
        </div>
      )}
    </div>
  );
};
