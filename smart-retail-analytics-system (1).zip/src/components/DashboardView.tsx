import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  DollarSign,
  ShoppingCart,
  Users,
  Layers,
  FileCheck2,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import { PreparedData } from '../types';
import { SalesAnalysisResult } from '../engine/salesAnalysis';

interface DashboardViewProps {
  data: PreparedData;
  salesAnalysis: SalesAnalysisResult;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ data, salesAnalysis }) => {
  const { quality } = data;
  const { monthlySales, topProductsRevenue } = salesAnalysis;

  const top10Products = topProductsRevenue.slice(0, 10);

  const qualityItems = [
    { label: 'Invalid InvoiceDate removed', value: quality.invalidDates, badgeColor: 'bg-[#FFF0F1] text-[#A84D55] border-[#F4CDD0]' },
    { label: 'Cancelled invoice rows (prefix C)', value: quality.cancelledRows, badgeColor: 'bg-[#FFF0F1] text-[#A84D55] border-[#F4CDD0]' },
    { label: 'Missing CustomerID rows (isolated from RFM)', value: quality.missingCustomerRows, badgeColor: 'bg-[#FFF8DB] text-[#8A6812] border-[#F5E6A8]' },
    { label: 'Duplicate rows in raw data', value: quality.duplicateRows, badgeColor: 'bg-[#EAF4FF] text-[#2867A8] border-[#CFE5FA]' },
    { label: 'Positive sales rows retained', value: quality.salesRows, badgeColor: 'bg-[#EAF8F0] text-[#287A50] border-[#CBEBD9]' },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Banner with Soft Pastel Gradient */}
      <div className="bg-gradient-to-r from-[#EAF4FF] via-[#F3EEFF] to-[#FFF1E5] p-6 rounded-2xl border border-[#CFE5FA] shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-white/80 text-[#2867A8] border border-[#CFE5FA] shadow-xs flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#5B9FE8]" /> Real-time Analytics
            </span>
            <span className="text-xs text-[#667085]">Zero mock values &bull; 100% computed</span>
          </div>
          <h2 className="text-xl font-bold text-[#243447] tracking-tight">Executive Analytics Dashboard</h2>
          <p className="text-xs text-[#667085] mt-1 max-w-2xl">
            Live retail intelligence computed directly from the uploaded dataset, tracking transaction velocity, catalog performance, and data health.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-white/90 border border-[#E7ECF2] px-3.5 py-2 rounded-xl text-xs text-[#243447] shadow-xs flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#62B88A]" />
            <span className="font-semibold text-[#287A50]">Date Span:</span>
            <span className="font-mono text-[#667085]">{quality.dateRange.start} → {quality.dateRange.end}</span>
          </div>
        </div>
      </div>

      {/* KPI Cards in Pastel Palette */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Blue: Raw Rows */}
        <div className="bg-gradient-to-b from-[#EAF4FF]/80 to-white border border-[#CFE5FA] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2867A8]">Raw Lines</span>
            <div className="w-8 h-8 rounded-xl bg-[#EAF4FF] flex items-center justify-center text-[#5B9FE8] border border-[#CFE5FA]">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {quality.rawRows.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Total lines in source CSV</div>
        </div>

        {/* Green: Sales Rows */}
        <div className="bg-gradient-to-b from-[#EAF8F0]/80 to-white border border-[#CBEBD9] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#287A50]">Sales Rows</span>
            <div className="w-8 h-8 rounded-xl bg-[#EAF8F0] flex items-center justify-center text-[#62B88A] border border-[#CBEBD9]">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#287A50] font-mono">
            {quality.salesRows.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Quantity &gt; 0 &bull; UnitPrice &gt; 0</div>
        </div>

        {/* Purple: Customers */}
        <div className="bg-gradient-to-b from-[#F3EEFF]/80 to-white border border-[#DDD1F7] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#6548A5]">Customers</span>
            <div className="w-8 h-8 rounded-xl bg-[#F3EEFF] flex items-center justify-center text-[#9B82D6] border border-[#DDD1F7]">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {quality.uniqueCustomers.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Unique valid CustomerIDs</div>
        </div>

        {/* Peach: Transactions */}
        <div className="bg-gradient-to-b from-[#FFF1E5]/80 to-white border border-[#F6D6BC] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#A55D25]">Invoices</span>
            <div className="w-8 h-8 rounded-xl bg-[#FFF1E5] flex items-center justify-center text-[#E9A66B] border border-[#F6D6BC]">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {quality.validTransactions.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Unique valid InvoiceNos</div>
        </div>

        {/* Yellow: Total Revenue */}
        <div className="bg-gradient-to-b from-[#FFF8DB]/80 to-white border border-[#F5E6A8] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8A6812]">Total Revenue</span>
            <div className="w-8 h-8 rounded-xl bg-[#FFF8DB] flex items-center justify-center text-[#E7B93F] border border-[#F5E6A8]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-[#243447] font-mono">
            ${quality.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Sum of Qty &times; UnitPrice</div>
        </div>
      </div>

      {/* Charts & Top Products Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Revenue Chart */}
        <div className="lg:col-span-7 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#EAF4FF] flex items-center justify-center text-[#5B9FE8]">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">Monthly Revenue Trajectory</h3>
                <p className="text-xs text-[#667085]">Gross sales aggregated across calendar YearMonths</p>
              </div>
            </div>
            <span className="text-xs font-mono font-medium px-2.5 py-1 bg-[#F1F7FD] rounded-full text-[#2867A8] border border-[#CFE5FA]">
              {monthlySales.length} calendar periods
            </span>
          </div>

          <div className="h-72 w-full flex-1">
            {monthlySales.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlySales} margin={{ top: 10, right: 20, left: 10, bottom: 20 }}>
                  <defs>
                    <linearGradient id="pastelBlueGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#5B9FE8" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#5B9FE8" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F0F4F8" />
                  <XAxis
                    dataKey="YearMonth"
                    tick={{ fontSize: 11, fill: '#667085' }}
                    angle={-30}
                    textAnchor="end"
                    height={40}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#667085' }}
                    tickFormatter={val => `$${(val / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    formatter={(value: number) => [
                      `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                      'Gross Revenue',
                    ]}
                    contentStyle={{
                      backgroundColor: '#FFFFFF',
                      borderColor: '#CFE5FA',
                      borderRadius: 12,
                      color: '#243447',
                      boxShadow: '0 4px 16px rgba(30, 60, 90, 0.08)',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="Revenue"
                    stroke="#5B9FE8"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#pastelBlueGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-[#98A2B3]">
                No monthly sales records available.
              </div>
            )}
          </div>
        </div>

        {/* Top 10 Products by Revenue */}
        <div className="lg:col-span-5 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-[#243447]">Top 10 Products by Revenue</h3>
              <p className="text-xs text-[#667085]">Highest grossing merchandise catalog items</p>
            </div>
            <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA]">
              Top Grossers
            </span>
          </div>

          <div className="flex-1 overflow-x-auto rounded-xl border border-[#E7ECF2]">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2]">
                <tr>
                  <th className="py-2.5 px-2.5 font-semibold">#</th>
                  <th className="py-2.5 px-2.5 font-semibold">Description</th>
                  <th className="py-2.5 px-2.5 font-semibold text-right">Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E7ECF2]">
                {top10Products.map((p, idx) => (
                  <tr key={idx} className="hover:bg-[#F9FBFC] transition-colors">
                    <td className="py-2 px-2.5 text-[#98A2B3] font-mono">
                      <span className="w-5 h-5 rounded-full bg-[#F1F7FD] text-[#2867A8] inline-flex items-center justify-center text-[10px] font-bold">
                        {idx + 1}
                      </span>
                    </td>
                    <td className="py-2 px-2.5 text-[#243447] font-medium truncate max-w-[190px]" title={p.name}>
                      {p.name}
                    </td>
                    <td className="py-2 px-2.5 text-right font-mono font-bold text-[#243447]">
                      ${p.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Data Quality Snapshot */}
      <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-[#243447]">Data Quality &amp; Pipeline Preprocessing Snapshot</h3>
            <p className="text-xs text-[#667085]">
              Systematic validation criteria ensuring analytical accuracy across downstream models
            </p>
          </div>
          <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
            Validated
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-[#E7ECF2]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2]">
              <tr>
                <th className="py-2.5 px-3 font-semibold">Pipeline Preprocessing Metric</th>
                <th className="py-2.5 px-3 font-semibold text-right">Row Count</th>
                <th className="py-2.5 px-3 font-semibold">Handling Strategy &amp; Analytical Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E7ECF2]">
              {qualityItems.map((item, i) => (
                <tr key={i} className="hover:bg-[#F9FBFC] transition-colors">
                  <td className="py-2.5 px-3 font-medium text-[#243447] flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border ${item.badgeColor}`}>
                      {i === 4 ? 'Retained' : 'Handled'}
                    </span>
                    <span>{item.label}</span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-[#243447]">
                    {item.value.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-[#667085]">
                    {i === 0 && 'Unparseable timestamps safely dropped from analytical tables to avoid chronological distortion.'}
                    {i === 1 && 'Filtered out from revenue calculation to avoid skewing positive sales trends and order volumes.'}
                    {i === 2 && 'Preserved for overall catalog velocity; isolated from RFM customer segmentation clustering.'}
                    {i === 3 && 'Detected and tracked across identical lines in raw input payload.'}
                    {i === 4 && 'Curated input dataset powering Sales, RFM, Association Rules, and Predictive ML.'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
