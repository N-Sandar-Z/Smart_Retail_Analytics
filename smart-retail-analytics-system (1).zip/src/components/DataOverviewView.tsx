import React from 'react';
import { Layers, Copy, AlertTriangle, FileCode2, Database, BarChart3 } from 'lucide-react';
import { PreparedData } from '../types';
import { REQUIRED_COLUMNS } from '../engine/dataParser';

interface DataOverviewViewProps {
  data: PreparedData;
}

export const DataOverviewView: React.FC<DataOverviewViewProps> = ({ data }) => {
  const { rawRows, quality } = data;

  // Compute missing values per column
  const totalRows = rawRows.length;
  const missingCounts: Record<string, number> = {};

  REQUIRED_COLUMNS.forEach(col => {
    missingCounts[col] = 0;
  });

  for (const row of rawRows) {
    for (const col of REQUIRED_COLUMNS) {
      const val = (row as any)[col];
      if (val === undefined || val === null || val === '' || String(val).trim() === 'NaN') {
        missingCounts[col]++;
      }
    }
  }

  const missingStats = REQUIRED_COLUMNS.map(col => ({
    column: col,
    missingCount: missingCounts[col],
    percentage: totalRows > 0 ? (missingCounts[col] / totalRows) * 100 : 0,
    dataType:
      col === 'Quantity' || col === 'UnitPrice'
        ? 'float64'
        : col === 'InvoiceDate'
        ? 'datetime64[ns]'
        : col === 'CustomerID'
        ? 'float64 (nullable)'
        : 'object (string)',
  }));

  // Preview first 20 raw rows
  const previewRows = rawRows.slice(0, 20);

  // Numerical summary for Quantity and UnitPrice
  const computeStats = (accessor: (r: any) => number) => {
    const vals = rawRows.map(accessor).filter(v => !isNaN(v) && isFinite(v));
    if (vals.length === 0) return { count: 0, mean: 0, std: 0, min: 0, q25: 0, median: 0, q75: 0, max: 0 };
    vals.sort((a, b) => a - b);
    const n = vals.length;
    const sum = vals.reduce((a, b) => a + b, 0);
    const mean = sum / n;
    const variance = vals.reduce((a, b) => a + (b - mean) ** 2, 0) / n;
    const std = Math.sqrt(variance);
    const min = vals[0];
    const max = vals[n - 1];
    const q25 = vals[Math.floor(n * 0.25)];
    const median = vals[Math.floor(n * 0.5)];
    const q75 = vals[Math.floor(n * 0.75)];
    return { count: n, mean, std, min, q25, median, q75, max };
  };

  const qtyStats = computeStats(r => r.Quantity);
  const priceStats = computeStats(r => r.UnitPrice);

  return (
    <div className="space-y-6">
      {/* View Header with Soft Blue Banner */}
      <div className="bg-gradient-to-r from-[#EAF4FF] to-white p-6 rounded-2xl border border-[#CFE5FA] shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#CFE5FA] text-[#2867A8]">
              Schema &amp; Data Health
            </span>
            <span className="text-xs text-[#667085]">• Raw Input Diagnostics</span>
          </div>
          <h2 className="text-xl font-bold text-[#243447] tracking-tight">Data Health &amp; Ingestion Overview</h2>
          <p className="text-xs text-[#667085] mt-1 max-w-2xl">
            Column type verification, completeness rates, duplicate tracking, and numerical distribution quantiles calculated from raw input data.
          </p>
        </div>
      </div>

      {/* Summary Cards in Fresh Pastel Tints */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-b from-[#EAF4FF]/80 to-white border border-[#CFE5FA] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2867A8]">Schema Columns</span>
            <div className="w-8 h-8 rounded-xl bg-[#EAF4FF] flex items-center justify-center text-[#5B9FE8] border border-[#CFE5FA]">
              <FileCode2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">{REQUIRED_COLUMNS.length}</div>
          <div className="mt-1 text-xs text-[#667085]">All 8 standard retail fields verified</div>
        </div>

        <div className="bg-gradient-to-b from-[#F3EEFF]/80 to-white border border-[#DDD1F7] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#6548A5]">Duplicate Rows</span>
            <div className="w-8 h-8 rounded-xl bg-[#F3EEFF] flex items-center justify-center text-[#9B82D6] border border-[#DDD1F7]">
              <Copy className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">{quality.duplicateRows.toLocaleString()}</div>
          <div className="mt-1 text-xs text-[#667085]">Identical lines detected in payload</div>
        </div>

        <div className="bg-gradient-to-b from-[#FFF8DB]/80 to-white border border-[#F5E6A8] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8A6812]">Missing CustomerID</span>
            <div className="w-8 h-8 rounded-xl bg-[#FFF8DB] flex items-center justify-center text-[#E7B93F] border border-[#F5E6A8]">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#8A6812] font-mono">
            {totalRows > 0 ? ((quality.missingCustomerRows / totalRows) * 100).toFixed(2) : 0}%
          </div>
          <div className="mt-1 text-xs text-[#667085]">
            {quality.missingCustomerRows.toLocaleString()} rows isolated from customer RFM
          </div>
        </div>
      </div>

      {/* Columns & Missing Values Table */}
      <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-[#243447]">Schema Columns &amp; Null Value Frequency</h3>
            <p className="text-xs text-[#667085]">Verification of mandatory fields and data type compliance</p>
          </div>
          <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA]">
            Strict Schema
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-[#E7ECF2]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2]">
              <tr>
                <th className="py-2.5 px-3 font-semibold">Column Name</th>
                <th className="py-2.5 px-3 font-semibold">Data Type</th>
                <th className="py-2.5 px-3 font-semibold text-right">Missing Count</th>
                <th className="py-2.5 px-3 font-semibold text-right">Missing Percentage</th>
                <th className="py-2.5 px-3 font-semibold text-center">Completeness Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E7ECF2]">
              {missingStats.map(stat => (
                <tr key={stat.column} className="hover:bg-[#F9FBFC] transition-colors">
                  <td className="py-2.5 px-3 font-mono font-semibold text-[#2867A8]">{stat.column}</td>
                  <td className="py-2.5 px-3 font-mono text-[#667085]">{stat.dataType}</td>
                  <td className="py-2.5 px-3 text-right font-mono text-[#243447]">
                    {stat.missingCount.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-[#243447]">
                    {stat.percentage.toFixed(2)}%
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {stat.missingCount === 0 ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                        100% Complete
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#FFF8DB] text-[#8A6812] border border-[#F5E6A8]">
                        Missing ({stat.missingCount.toLocaleString()})
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Descriptive Statistics Table */}
      <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-[#243447]">Numerical Descriptive Statistics</h3>
            <p className="text-xs text-[#667085]">Five-number summary, mean, and dispersion for numeric variables</p>
          </div>
          <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#F3EEFF] text-[#6548A5] border border-[#DDD1F7]">
            Distribution Summary
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-[#E7ECF2]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2]">
              <tr>
                <th className="py-2.5 px-3 font-semibold">Distribution Metric</th>
                <th className="py-2.5 px-3 font-semibold text-right">Quantity (Units)</th>
                <th className="py-2.5 px-3 font-semibold text-right">UnitPrice ($ USD)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E7ECF2] font-mono">
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">Total Count (N)</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">{qtyStats.count.toLocaleString()}</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">{priceStats.count.toLocaleString()}</td>
              </tr>
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">Arithmetic Mean</td>
                <td className="py-2.5 px-3 text-right text-[#2867A8] font-semibold">{qtyStats.mean.toFixed(2)}</td>
                <td className="py-2.5 px-3 text-right text-[#2867A8] font-semibold">${priceStats.mean.toFixed(2)}</td>
              </tr>
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">Standard Deviation (&sigma;)</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">{qtyStats.std.toFixed(2)}</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">${priceStats.std.toFixed(2)}</td>
              </tr>
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">Minimum Value</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">{qtyStats.min}</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">${priceStats.min.toFixed(2)}</td>
              </tr>
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">25th Percentile (Q1)</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">{qtyStats.q25}</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">${priceStats.q25.toFixed(2)}</td>
              </tr>
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">50th Percentile (Median)</td>
                <td className="py-2.5 px-3 text-right text-[#287A50] font-bold">{qtyStats.median}</td>
                <td className="py-2.5 px-3 text-right text-[#287A50] font-bold">${priceStats.median.toFixed(2)}</td>
              </tr>
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">75th Percentile (Q3)</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">{qtyStats.q75}</td>
                <td className="py-2.5 px-3 text-right text-[#243447]">${priceStats.q75.toFixed(2)}</td>
              </tr>
              <tr className="hover:bg-[#F9FBFC]">
                <td className="py-2.5 px-3 font-sans font-medium text-[#667085]">Maximum Value</td>
                <td className="py-2.5 px-3 text-right text-[#243447] font-bold">{qtyStats.max.toLocaleString()}</td>
                <td className="py-2.5 px-3 text-right text-[#243447] font-bold">${priceStats.max.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Preview First 20 Rows */}
      <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-[#243447]">Dataset Ingestion Preview (First 20 Records)</h3>
            <p className="text-xs text-[#667085]">Raw transactions as parsed into in-memory structure</p>
          </div>
          <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA]">
            Sample Window
          </span>
        </div>

        <div className="overflow-x-auto max-h-96 rounded-xl border border-[#E7ECF2]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
              <tr>
                <th className="py-2 px-2.5 font-semibold">#</th>
                <th className="py-2 px-2.5 font-semibold">InvoiceNo</th>
                <th className="py-2 px-2.5 font-semibold">StockCode</th>
                <th className="py-2 px-2.5 font-semibold">Description</th>
                <th className="py-2 px-2.5 font-semibold text-right">Quantity</th>
                <th className="py-2 px-2.5 font-semibold">InvoiceDate</th>
                <th className="py-2 px-2.5 font-semibold text-right">UnitPrice</th>
                <th className="py-2 px-2.5 font-semibold">CustomerID</th>
                <th className="py-2 px-2.5 font-semibold">Country</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E7ECF2] font-mono">
              {previewRows.map((r, idx) => (
                <tr key={idx} className="hover:bg-[#F9FBFC] transition-colors">
                  <td className="py-2 px-2.5 text-[#98A2B3]">{idx + 1}</td>
                  <td className="py-2 px-2.5 text-[#2867A8] font-semibold">{r.InvoiceNo}</td>
                  <td className="py-2 px-2.5 text-[#667085]">{r.StockCode}</td>
                  <td className="py-2 px-2.5 font-sans text-[#243447] truncate max-w-xs" title={r.Description}>
                    {r.Description}
                  </td>
                  <td className="py-2 px-2.5 text-right text-[#243447] font-semibold">{r.Quantity}</td>
                  <td className="py-2 px-2.5 text-[#667085]">{r.InvoiceDate}</td>
                  <td className="py-2 px-2.5 text-right text-[#243447]">${r.UnitPrice.toFixed(2)}</td>
                  <td className="py-2 px-2.5 text-[#667085]">{r.CustomerID || <span className="text-[#98A2B3] italic">null</span>}</td>
                  <td className="py-2 px-2.5 font-sans text-[#243447]">{r.Country}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
