import React, { useRef, useState } from 'react';
import {
  LayoutDashboard,
  FileSpreadsheet,
  TrendingUp,
  Users,
  GitFork,
  Calendar,
  BrainCircuit,
  Lightbulb,
  Upload,
  Database,
  CheckCircle2,
  AlertCircle,
  Menu,
  X,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { DataQualityMetrics } from '../types';

export type ActiveTab =
  | 'dashboard'
  | 'data-overview'
  | 'sales-analysis'
  | 'customer-segmentation'
  | 'association-analysis'
  | 'temporal-analysis'
  | 'predictive-analysis'
  | 'business-insights';

interface NavItemConfig {
  id: ActiveTab;
  label: string;
  category: string;
  icon: React.ComponentType<{ className?: string }>;
  activeBg: string;
  activeText: string;
  activeBorder: string;
  indicatorBg: string;
  hoverBg: string;
}

const NAV_ITEMS: NavItemConfig[] = [
  {
    id: 'dashboard',
    label: 'Overview Dashboard',
    category: 'Core Analytics',
    icon: LayoutDashboard,
    activeBg: 'bg-[#EAF4FF]',
    activeText: 'text-[#2867A8]',
    activeBorder: 'border-[#CFE5FA]',
    indicatorBg: 'bg-[#5B9FE8]',
    hoverBg: 'hover:bg-[#EAF4FF]/70 hover:text-[#2867A8]',
  },
  {
    id: 'data-overview',
    label: 'Data Health & Schema',
    category: 'Core Analytics',
    icon: FileSpreadsheet,
    activeBg: 'bg-[#EAF4FF]',
    activeText: 'text-[#2867A8]',
    activeBorder: 'border-[#CFE5FA]',
    indicatorBg: 'bg-[#5B9FE8]',
    hoverBg: 'hover:bg-[#EAF4FF]/70 hover:text-[#2867A8]',
  },
  {
    id: 'sales-analysis',
    label: 'Sales Analysis',
    category: 'Performance',
    icon: TrendingUp,
    activeBg: 'bg-[#EAF4FF]',
    activeText: 'text-[#2867A8]',
    activeBorder: 'border-[#CFE5FA]',
    indicatorBg: 'bg-[#5B9FE8]',
    hoverBg: 'hover:bg-[#EAF4FF]/70 hover:text-[#2867A8]',
  },
  {
    id: 'customer-segmentation',
    label: 'Customer Segmentation',
    category: 'Segmentation',
    icon: Users,
    activeBg: 'bg-[#F3EEFF]',
    activeText: 'text-[#6548A5]',
    activeBorder: 'border-[#DDD1F7]',
    indicatorBg: 'bg-[#9B82D6]',
    hoverBg: 'hover:bg-[#F3EEFF]/70 hover:text-[#6548A5]',
  },
  {
    id: 'association-analysis',
    label: 'Market Basket Analysis',
    category: 'Affinity Mining',
    icon: GitFork,
    activeBg: 'bg-[#FFF1E5]',
    activeText: 'text-[#A55D25]',
    activeBorder: 'border-[#F6D6BC]',
    indicatorBg: 'bg-[#E9A66B]',
    hoverBg: 'hover:bg-[#FFF1E5]/70 hover:text-[#A55D25]',
  },
  {
    id: 'temporal-analysis',
    label: 'Temporal Association',
    category: 'Affinity Mining',
    icon: Calendar,
    activeBg: 'bg-[#E9F9FB]',
    activeText: 'text-[#287F89]',
    activeBorder: 'border-[#C8ECEF]',
    indicatorBg: 'bg-[#54B9C5]',
    hoverBg: 'hover:bg-[#E9F9FB]/70 hover:text-[#287F89]',
  },
  {
    id: 'predictive-analysis',
    label: 'Best-Seller Prediction',
    category: 'Machine Learning',
    icon: BrainCircuit,
    activeBg: 'bg-[#EAF8F0]',
    activeText: 'text-[#287A50]',
    activeBorder: 'border-[#CBEBD9]',
    indicatorBg: 'bg-[#62B88A]',
    hoverBg: 'hover:bg-[#EAF8F0]/70 hover:text-[#287A50]',
  },
  {
    id: 'business-insights',
    label: 'Business Insights',
    category: 'Strategy',
    icon: Lightbulb,
    activeBg: 'bg-[#FFF8DB]',
    activeText: 'text-[#8A6812]',
    activeBorder: 'border-[#F5E6A8]',
    indicatorBg: 'bg-[#E7B93F]',
    hoverBg: 'hover:bg-[#FFF8DB]/70 hover:text-[#8A6812]',
  },
];

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  quality: DataQualityMetrics | null;
  onFileUpload: (file: File) => void;
  onLoadBenchmark: () => void;
  isLoading: boolean;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  quality,
  onFileUpload,
  onLoadBenchmark,
  isLoading,
  isOpenMobile,
  onCloseMobile,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileUpload(e.target.files[0]);
      e.target.value = '';
    }
  };

  const navContent = (
    <div className="flex flex-col h-full bg-[#F1F7FD] border-r border-[#E2EAF3] text-[#243447]">
      {/* Brand Header */}
      <div className="p-5 border-b border-[#E2EAF3] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#5B9FE8] to-[#9B82D6] flex items-center justify-center font-bold text-white shadow-[0_2px_8px_rgba(91,159,232,0.3)] text-sm">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="text-sm font-bold tracking-tight text-[#243447] flex items-center gap-1.5">
              Smart Retail
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA] font-medium">
                Mining
              </span>
            </div>
            <div className="text-[11px] text-[#667085] font-medium">Analytics Dashboard</div>
          </div>
        </div>
        {isOpenMobile && (
          <button
            onClick={onCloseMobile}
            className="md:hidden p-1.5 rounded-lg text-[#667085] hover:bg-[#EAF4FF] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Dataset Status Banner */}
      <div className="px-4 py-3 border-b border-[#E2EAF3]/80 bg-[#EAF4FF]/40">
        {quality ? (
          <div className="flex items-center gap-2 text-xs">
            <div className="w-2 h-2 rounded-full bg-[#62B88A] animate-pulse" />
            <div className="truncate">
              <span className="font-semibold text-[#287A50]">
                {quality.salesRows.toLocaleString()}
              </span>{' '}
              <span className="text-[#667085]">sales rows active</span>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-xs text-[#8A6812]">
            <div className="w-2 h-2 rounded-full bg-[#E7B93F]" />
            <span>Ready for data upload</span>
          </div>
        )}
      </div>

      {/* Navigation Links */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-[#98A2B3]">
          Navigation Modules
        </div>
        {NAV_ITEMS.map(item => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => {
                onSelectTab(item.id);
                onCloseMobile();
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer relative ${
                isActive
                  ? `${item.activeBg} ${item.activeText} ${item.activeBorder} border shadow-[0_2px_8px_rgba(30,60,90,0.04)] font-semibold`
                  : `text-[#667085] ${item.hoverBg}`
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                    isActive ? 'bg-white shadow-xs' : 'bg-transparent text-[#667085]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span>{item.label}</span>
              </div>
              {isActive && (
                <div className={`w-1.5 h-4 rounded-full ${item.indicatorBg} mr-0.5`} />
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom Actions: CSV & Benchmark */}
      <div className="p-4 border-t border-[#E2EAF3] space-y-2 bg-[#F1F7FD]">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".csv"
          className="hidden"
          id="sidebar-csv-file-input"
        />

        <button
          id="sidebar-upload-btn"
          onClick={() => fileInputRef.current?.click()}
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-[#5B9FE8] hover:bg-[#4a8fd9] text-white transition shadow-[0_2px_8px_rgba(91,159,232,0.3)] disabled:opacity-50 cursor-pointer"
        >
          <Upload className="w-3.5 h-3.5" />
          Upload Retail CSV
        </button>

        <button
          id="sidebar-benchmark-btn"
          onClick={onLoadBenchmark}
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium bg-[#EAF4FF] hover:bg-[#d9ecff] text-[#2867A8] border border-[#CFE5FA] transition disabled:opacity-50 cursor-pointer"
        >
          <Database className="w-3.5 h-3.5 text-[#5B9FE8]" />
          Load Benchmark Sample
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:block w-64 flex-shrink-0 h-screen sticky top-0 z-30">
        {navContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/30 backdrop-blur-xs"
            onClick={onCloseMobile}
          />
          <div className="relative w-64 max-w-[85vw] h-full shadow-2xl z-10">
            {navContent}
          </div>
        </div>
      )}
    </>
  );
};

interface HeaderProps {
  onOpenMobile: () => void;
  quality: DataQualityMetrics | null;
  onRefresh: () => void;
  isLoading: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenMobile,
  quality,
  onRefresh,
  isLoading,
}) => {
  return (
    <header className="bg-white/90 backdrop-blur-md border-b border-[#E7ECF2] sticky top-0 z-20 px-4 sm:px-6 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobile}
            className="md:hidden p-2 rounded-xl bg-[#F1F7FD] text-[#2867A8] border border-[#E2EAF3] cursor-pointer"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#243447] tracking-tight leading-tight">
              Retail Data Mining Analytics
            </h1>
            <p className="text-xs text-[#667085] hidden sm:block">
              Real-time Data-Driven Retail Intelligence &bull; Python Analytic Engine Single Source of Truth
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {quality ? (
            <div className="hidden lg:flex items-center gap-2 bg-[#EAF8F0] border border-[#CBEBD9] px-3 py-1.5 rounded-full text-xs text-[#287A50]">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#62B88A]" />
              <span>
                <strong>{quality.salesRows.toLocaleString()}</strong> Sales Transactions (
                {quality.dateRange.start} &rarr; {quality.dateRange.end})
              </span>
            </div>
          ) : (
            <div className="hidden lg:flex items-center gap-2 bg-[#FFF8DB] border border-[#F5E6A8] px-3 py-1.5 rounded-full text-xs text-[#8A6812]">
              <AlertCircle className="w-3.5 h-3.5 text-[#E7B93F]" />
              <span>Awaiting CSV ingestion or benchmark sample</span>
            </div>
          )}

          <button
            onClick={onRefresh}
            disabled={isLoading || !quality}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-[#F1F7FD] hover:bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA] transition disabled:opacity-50 cursor-pointer"
            title="Re-run analytics pipeline from currently ingested data"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#5B9FE8] ${isLoading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh Analysis</span>
          </button>
        </div>
      </div>
    </header>
  );
};
