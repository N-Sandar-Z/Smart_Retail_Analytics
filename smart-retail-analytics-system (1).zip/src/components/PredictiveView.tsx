import React, { useState } from 'react';
import { Play, BrainCircuit, Award, CheckCircle2, TrendingUp, Sparkles, Layers, Clock } from 'lucide-react';
import { PredictiveAnalysisState, MLModelResult } from '../types';

interface PredictiveViewProps {
  predictiveState: PredictiveAnalysisState | null;
  onTrainModel: (modelName: string, compareAll: boolean) => void;
  isTraining: boolean;
  onPrepareML: () => void;
  isPreparing: boolean;
}

export const PredictiveView: React.FC<PredictiveViewProps> = ({
  predictiveState,
  onTrainModel,
  isTraining,
  onPrepareML,
  isPreparing,
}) => {
  const [selectedModel, setSelectedModel] = useState<string>('Random Forest');

  const modelResults: MLModelResult[] = predictiveState
    ? (Object.values(predictiveState.results) as MLModelResult[])
    : [];

  const activeModelData: MLModelResult | undefined =
    modelResults.find(m => m.modelName.toLowerCase() === selectedModel.toLowerCase()) ||
    modelResults[0];

  // Best model by accuracy
  const bestModel = modelResults.length > 0
    ? [...modelResults].sort((a, b) => b.accuracy - a.accuracy)[0]
    : null;

  return (
    <div className="space-y-6">
      {/* View Header with Soft Green Accent */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-gradient-to-r from-[#EAF8F0] to-white p-6 rounded-2xl border border-[#CBEBD9] shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#CBEBD9] text-[#287A50]">
              Supervised Machine Learning
            </span>
            <span className="text-xs text-[#667085]">• Time-Series Train/Test Split (80/20)</span>
          </div>
          <h2 className="text-xl font-bold text-[#243447] tracking-tight">Best-Seller Prediction &amp; Classification</h2>
          <p className="text-xs text-[#667085] mt-1 max-w-2xl">
            Predict upcoming month best-sellers (Top 25% sales volume threshold) using Logistic Regression, Random Forest, and XGBoost classifiers with mutual information feature selection.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="train-all-models-btn"
            onClick={() => onTrainModel('Random Forest', true)}
            disabled={isTraining || !predictiveState}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#62B88A] hover:bg-[#52a679] text-white font-medium text-xs shadow-[0_2px_8px_rgba(98,184,138,0.3)] transition disabled:opacity-50 cursor-pointer whitespace-nowrap"
          >
            {isTraining ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Training All Models...
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                Train &amp; Compare All Models
              </>
            )}
          </button>
        </div>
      </div>

      {predictiveState ? (
        <>
          {/* Dataset Split & Feature Selection Info */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-gradient-to-b from-[#EAF8F0]/80 to-white border border-[#CBEBD9] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#287A50]">Training Split</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                  {predictiveState.trainPeriod.start} → {predictiveState.trainPeriod.end}
                </span>
              </div>
              <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
                {predictiveState.trainRowsCount.toLocaleString()}
              </div>
              <div className="mt-1 text-xs text-[#667085]">Historical monthly product observations</div>
            </div>

            <div className="bg-gradient-to-b from-[#EAF4FF]/80 to-white border border-[#CFE5FA] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#2867A8]">Evaluation Split</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA]">
                  {predictiveState.testPeriod.start} → {predictiveState.testPeriod.end}
                </span>
              </div>
              <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
                {predictiveState.testRowsCount.toLocaleString()}
              </div>
              <div className="mt-1 text-xs text-[#667085]">Out-of-sample forward test rows</div>
            </div>

            <div className="bg-gradient-to-b from-[#F3EEFF]/80 to-white border border-[#DDD1F7] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#6548A5]">Engineered Features</span>
                <div className="w-8 h-8 rounded-xl bg-[#F3EEFF] flex items-center justify-center text-[#9B82D6] border border-[#DDD1F7]">
                  <Layers className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 text-3xl font-bold text-[#6548A5] font-mono">
                {predictiveState.featureCount} Features
              </div>
              <div className="mt-1 text-xs text-[#667085]">Top 10 selected via Mutual Information</div>
            </div>

            <div className="bg-gradient-to-b from-[#FFF8DB]/80 to-white border border-[#F5E6A8] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-[#8A6812]">Champion Model</span>
                <div className="w-8 h-8 rounded-xl bg-[#FFF8DB] flex items-center justify-center text-[#E7B93F] border border-[#F5E6A8]">
                  <Award className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 text-2xl font-bold text-[#243447]">
                {bestModel ? bestModel.modelName : 'Pending'}
              </div>
              <div className="mt-1 text-xs text-[#8A6812] font-mono font-bold">
                {bestModel ? `${(bestModel.accuracy * 100).toFixed(1)}% Accuracy` : 'Train models to rank'}
              </div>
            </div>
          </div>

          {modelResults.length > 0 ? (
            <>
              {/* Model Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {modelResults.map(m => {
                  const isSelected = activeModelData?.modelName === m.modelName;
                  const isChampion = bestModel?.modelName === m.modelName;
                  return (
                    <div
                      key={m.modelName}
                      onClick={() => setSelectedModel(m.modelName)}
                      className={`bg-white rounded-2xl p-5 border transition cursor-pointer shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between ${
                        isSelected
                          ? 'border-[#62B88A] ring-2 ring-[#CBEBD9]'
                          : 'border-[#E7ECF2] hover:border-[#CBEBD9]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-[#243447]">{m.modelName}</span>
                        {isChampion && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FFF8DB] text-[#8A6812] border border-[#F5E6A8] font-bold">
                            Champion
                          </span>
                        )}
                      </div>

                      <div className="mt-4 space-y-2 text-xs font-mono">
                        <div className="flex justify-between items-center">
                          <span className="font-sans text-[#667085]">Accuracy:</span>
                          <span className="text-lg font-bold text-[#287A50]">
                            {(m.accuracy * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="font-sans text-[#667085]">Training Latency:</span>
                          <span className="text-[#243447]">{m.trainTimeSeconds.toFixed(3)}s</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="font-sans text-[#667085]">Predicted Best-Sellers:</span>
                          <span className="font-bold text-[#2867A8]">{m.predictedBestSellerCount.toLocaleString()}</span>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedModel(m.modelName);
                          onTrainModel(m.modelName, false);
                        }}
                        disabled={isTraining}
                        className="mt-4 w-full py-1.5 rounded-xl bg-[#F1F7FD] hover:bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA] text-xs font-medium cursor-pointer transition"
                      >
                        Re-train This Model
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Deep Dive: Confusion Matrix & Mutual Information */}
              {activeModelData && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Confusion Matrix */}
                  <div className="lg:col-span-6 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-sm font-semibold text-[#243447]">
                          Confusion Matrix &bull; {activeModelData.modelName}
                        </h3>
                        <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA]">
                          Out-of-Sample Test
                        </span>
                      </div>
                      <p className="text-xs text-[#667085] mb-4">
                        Contingency matrix evaluating predictions against true forward best-seller status.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                      <div className="bg-[#EAF8F0] border border-[#CBEBD9] p-4 rounded-xl text-center">
                        <div className="text-[11px] font-sans font-semibold text-[#287A50] mb-1">True Negatives (TN)</div>
                        <div className="text-2xl font-bold text-[#287A50]">
                          {activeModelData.confusionMatrix[0][0].toLocaleString()}
                        </div>
                        <div className="text-[10px] text-[#667085] font-sans mt-1">Correct Regular Items</div>
                      </div>

                      <div className="bg-[#FFF0F1] border border-[#F4CDD0] p-4 rounded-xl text-center">
                        <div className="text-[11px] font-sans font-semibold text-[#A84D55] mb-1">False Positives (FP)</div>
                        <div className="text-2xl font-bold text-[#A84D55]">
                          {activeModelData.confusionMatrix[0][1].toLocaleString()}
                        </div>
                        <div className="text-[10px] text-[#667085] font-sans mt-1">Type I False Alarm</div>
                      </div>

                      <div className="bg-[#FFF0F1] border border-[#F4CDD0] p-4 rounded-xl text-center">
                        <div className="text-[11px] font-sans font-semibold text-[#A84D55] mb-1">False Negatives (FN)</div>
                        <div className="text-2xl font-bold text-[#A84D55]">
                          {activeModelData.confusionMatrix[1][0].toLocaleString()}
                        </div>
                        <div className="text-[10px] text-[#667085] font-sans mt-1">Type II Missed Spike</div>
                      </div>

                      <div className="bg-[#EAF8F0] border border-[#CBEBD9] p-4 rounded-xl text-center">
                        <div className="text-[11px] font-sans font-semibold text-[#287A50] mb-1">True Positives (TP)</div>
                        <div className="text-2xl font-bold text-[#287A50]">
                          {activeModelData.confusionMatrix[1][1].toLocaleString()}
                        </div>
                        <div className="text-[10px] text-[#667085] font-sans mt-1">Correct Bestsellers</div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#E7ECF2] flex items-center justify-between text-xs text-[#667085]">
                      <span>Evaluated Forward Products:</span>
                      <span className="font-mono font-bold text-[#243447]">
                        {(
                          activeModelData.confusionMatrix[0][0] +
                          activeModelData.confusionMatrix[0][1] +
                          activeModelData.confusionMatrix[1][0] +
                          activeModelData.confusionMatrix[1][1]
                        ).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Mutual Information Feature Importance */}
                  <div className="lg:col-span-6 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-sm font-semibold text-[#243447]">
                          Mutual Information Feature Ranking
                        </h3>
                        <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-[#F3EEFF] text-[#6548A5] border border-[#DDD1F7]">
                          Mutual Info
                        </span>
                      </div>
                      <p className="text-xs text-[#667085] mb-4">
                        Nonlinear correlation and dependency scores of engineered predictors.
                      </p>
                    </div>

                    <div className="space-y-2.5">
                      {activeModelData.featureScores.slice(0, 7).map((feat, i) => (
                        <div key={i} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="font-medium text-[#243447]">{feat.Feature}</span>
                            <span className="font-mono text-[#667085]">{feat.Score.toFixed(4)}</span>
                          </div>
                          <div className="w-full h-2 rounded-full bg-[#F1F7FD] overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-[#62B88A] to-[#5B9FE8]"
                              style={{ width: `${Math.max(6, Math.min(100, (feat.Score / 0.5) * 100))}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#E7ECF2] text-[11px] text-[#667085]">
                      Features selected with highest mutual info: Lag sales, rolling quantities, purchase frequency, and revenue momentum.
                    </div>
                  </div>
                </div>
              )}

              {/* Predictions Sample Table */}
              {predictiveState.predictions.length > 0 && (
                <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="text-sm font-semibold text-[#243447]">
                        Upcoming Period Best-Seller Predictions (Sample of {predictiveState.predictions.length} Products)
                      </h3>
                      <p className="text-xs text-[#667085]">
                        Model forecast generated for the upcoming forward evaluation period.
                      </p>
                    </div>
                    <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                      Forecast Output
                    </span>
                  </div>

                  <div className="overflow-x-auto max-h-80 rounded-xl border border-[#E7ECF2]">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
                        <tr>
                          <th className="py-2.5 px-3 font-semibold">StockCode</th>
                          <th className="py-2.5 px-3 font-semibold">Description</th>
                          <th className="py-2.5 px-3 font-semibold">Forecast Month</th>
                          <th className="py-2.5 px-3 font-semibold text-center">Predicted Status</th>
                          <th className="py-2.5 px-3 font-semibold text-right">Confidence Score</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#E7ECF2] font-mono">
                        {predictiveState.predictions.slice(0, 50).map((row, i) => (
                          <tr key={i} className="hover:bg-[#F9FBFC] transition-colors">
                            <td className="py-2 px-3 text-[#2867A8] font-bold">{row.StockCode}</td>
                            <td className="py-2 px-3 font-sans font-medium text-[#243447] truncate max-w-xs" title={row.Description}>
                              {row.Description}
                            </td>
                            <td className="py-2 px-3 text-[#667085]">{row.PredictionMonth}</td>
                            <td className="py-2 px-3 text-center font-sans">
                              {row.Predicted_Best_Seller === 1 ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                                  ★ Best-Seller
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-[#F1F7FD] text-[#667085] border border-[#CFE5FA]">
                                  Regular
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-[#243447]">
                              {(row.Prediction_Probability * 100).toFixed(1)}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="bg-white border border-[#E7ECF2] rounded-2xl p-10 text-center shadow-[0_4px_16px_rgba(30,60,90,0.03)] space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#EAF8F0] border border-[#CBEBD9] flex items-center justify-center mx-auto text-[#62B88A]">
                <BrainCircuit className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#243447]">Models Ready For Training</h3>
                <p className="text-xs text-[#667085] mt-1 max-w-md mx-auto">
                  {predictiveState.trainRowsCount.toLocaleString()} training rows and {predictiveState.testRowsCount.toLocaleString()} test rows have been split and prepared. Click below to begin training.
                </p>
              </div>
              <button
                onClick={() => onTrainModel('Random Forest', true)}
                disabled={isTraining}
                className="px-5 py-2.5 rounded-xl bg-[#62B88A] hover:bg-[#52a679] text-white font-semibold text-xs shadow-sm transition disabled:opacity-50 cursor-pointer"
              >
                Train &amp; Compare All 3 Classifiers
              </button>
            </div>
          )}
        </>
      ) : (
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-12 text-center shadow-[0_4px_16px_rgba(30,60,90,0.03)] space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#EAF8F0] border border-[#CBEBD9] flex items-center justify-center mx-auto text-[#62B88A]">
            <BrainCircuit className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#243447]">Predictive Feature Pipeline</h3>
            <p className="text-xs text-[#667085] mt-1 max-w-md mx-auto">
              Prepare monthly product time-series lag features to enable supervised best-seller forecasting.
            </p>
          </div>
          <button
            onClick={onPrepareML}
            disabled={isPreparing}
            className="px-5 py-2.5 rounded-xl bg-[#62B88A] hover:bg-[#52a679] text-white font-semibold text-xs shadow-sm transition disabled:opacity-50 cursor-pointer"
          >
            {isPreparing ? 'Extracting Features...' : 'Extract Time-Series ML Features'}
          </button>
        </div>
      )}
    </div>
  );
};
