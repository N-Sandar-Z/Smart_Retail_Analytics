import React, { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { ShoppingBag, DollarSign, Globe, TrendingUp, BarChart2 } from 'lucide-react';
import { SalesAnalysisResult } from '../engine/salesAnalysis';

interface SalesAnalysisViewProps {
  salesAnalysis: SalesAnalysisResult;
}

export const SalesAnalysisView: React.FC<SalesAnalysisViewProps> = ({ salesAnalysis }) => {
  const [productTab, setProductTab] = useState<'revenue' | 'quantity'>('revenue');

  const {
    monthlySales,
    yearlySales,
    topCountries,
    topProductsQuantity,
    topProductsRevenue,
    validTransactionsCount,
    averageOrderValue,
    sampleTransactions,
  } = salesAnalysis;

  return (
    <div className="space-y-6">
      {/* View Header with Soft Blue/Cyan Banner */}
      <div className="bg-gradient-to-r from-[#EAF4FF] via-white to-[#E9F9FB] p-6 rounded-2xl border border-[#CFE5FA] shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#CFE5FA] text-[#2867A8]">
              Sales &amp; Geographic Intelligence
            </span>
            <span className="text-xs text-[#667085]">• Revenue Velocity</span>
          </div>
          <h2 className="text-xl font-bold text-[#243447] tracking-tight">Sales &amp; Transaction Analysis</h2>
          <p className="text-xs text-[#667085] mt-1 max-w-2xl">
            Order volume trends, average transaction basket sizing, geographic revenue distribution, and catalog item velocity.
          </p>
        </div>
      </div>

      {/* Transaction Summary KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-gradient-to-b from-[#EAF4FF]/80 to-white border border-[#CFE5FA] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2867A8]">Valid Orders</span>
            <div className="w-8 h-8 rounded-xl bg-[#EAF4FF] flex items-center justify-center text-[#5B9FE8] border border-[#CFE5FA]">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {validTransactionsCount.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">
            Distinct positive sales invoices (cancellations filtered out)
          </div>
        </div>

        <div className="bg-gradient-to-b from-[#F3EEFF]/80 to-white border border-[#DDD1F7] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#6548A5]">Average Order Value (AOV)</span>
            <div className="w-8 h-8 rounded-xl bg-[#F3EEFF] flex items-center justify-center text-[#9B82D6] border border-[#DDD1F7]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#6548A5] font-mono">
            ${averageOrderValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="mt-1 text-xs text-[#667085]">
            Mean gross basket spend across validated customer transactions
          </div>
        </div>
      </div>

      {/* Charts: Monthly & Yearly Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trend */}
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#EAF4FF] flex items-center justify-center text-[#5B9FE8]">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">Monthly Revenue Trend</h3>
                <p className="text-xs text-[#667085]">Sales trajectory across calendar periods</p>
              </div>
            </div>
            <span className="text-xs font-mono font-medium px-2.5 py-1 bg-[#F1F7FD] rounded-full text-[#2867A8] border border-[#CFE5FA]">
              {monthlySales.length} Months
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlySales} margin={{ top: 10, right: 20, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F0F4F8" />
                <XAxis dataKey="YearMonth" tick={{ fontSize: 11, fill: '#667085' }} angle={-30} textAnchor="end" height={40} />
                <YAxis tick={{ fontSize: 11, fill: '#667085' }} tickFormatter={val => `$${(val / 1000).toFixed(0)}k`} />
                <Tooltip
                  formatter={(val: number) => [`$${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Revenue']}
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderColor: '#CFE5FA',
                    borderRadius: 12,
                    color: '#243447',
                    boxShadow: '0 4px 16px rgba(30, 60, 90, 0.08)',
                    fontSize: '12px',
                  }}
                />
                <Line type="monotone" dataKey="Revenue" stroke="#5B9FE8" strokeWidth={2.5} dot={{ r: 4, fill: '#5B9FE8', stroke: '#FFFFFF', strokeWidth: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Yearly Trend */}
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#F3EEFF] flex items-center justify-center text-[#9B82D6]">
                <BarChart2 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">Annual Revenue Comparison</h3>
                <p className="text-xs text-[#667085]">Aggregated yearly gross sales volume</p>
              </div>
            </div>
            <span className="text-xs font-mono font-medium px-2.5 py-1 bg-[#F3EEFF] rounded-full text-[#6548A5] border border-[#DDD1F7]">
              Annual Totals
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={yearlySales} margin={{ top: 10, right: 20, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F0F4F8" />
                <XAxis dataKey="Year" tick={{ fontSize: 12, fill: '#667085' }} />
                <YAxis tick={{ fontSize: 11, fill: '#667085' }} tickFormatter={val => `$${(val / 1000).toFixed(0)}k`} />
                <Tooltip
                  formatter={(val: number) => [`$${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Revenue']}
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderColor: '#DDD1F7',
                    borderRadius: 12,
                    color: '#243447',
                    boxShadow: '0 4px 16px rgba(30, 60, 90, 0.08)',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="Revenue" fill="#9B82D6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Top Countries & Top Products */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top 15 Countries */}
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#EAF8F0] flex items-center justify-center text-[#62B88A]">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">Top 15 Countries by Revenue</h3>
                <p className="text-xs text-[#667085]">International market contribution</p>
              </div>
            </div>
            <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
              Markets
            </span>
          </div>

          <div className="overflow-x-auto flex-1 max-h-96 rounded-xl border border-[#E7ECF2]">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">#</th>
                  <th className="py-2.5 px-3 font-semibold">Country</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Revenue ($)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E7ECF2] font-mono">
                {topCountries.map((c, i) => (
                  <tr key={i} className="hover:bg-[#F9FBFC] transition-colors">
                    <td className="py-2 px-3 text-[#98A2B3]">
                      <span className="w-5 h-5 rounded-full bg-[#F1F7FD] text-[#2867A8] inline-flex items-center justify-center text-[10px] font-bold">
                        {i + 1}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-sans font-medium text-[#243447]">{c.name}</td>
                    <td className="py-2 px-3 text-right font-semibold text-[#243447]">
                      ${c.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top 15 Products (Toggle Quantity / Revenue) */}
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-[#243447]">Top 15 Catalog Products</h3>
              <p className="text-xs text-[#667085]">Ranked by monetary revenue or unit velocity</p>
            </div>
            <div className="flex bg-[#F1F7FD] p-1 rounded-xl border border-[#CFE5FA] text-xs">
              <button
                onClick={() => setProductTab('revenue')}
                className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition ${
                  productTab === 'revenue'
                    ? 'bg-white shadow-xs text-[#2867A8] font-bold'
                    : 'text-[#667085] hover:text-[#243447]'
                }`}
              >
                Revenue
              </button>
              <button
                onClick={() => setProductTab('quantity')}
                className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition ${
                  productTab === 'quantity'
                    ? 'bg-white shadow-xs text-[#2867A8] font-bold'
                    : 'text-[#667085] hover:text-[#243447]'
                }`}
              >
                Quantity
              </button>
            </div>
          </div>

          <div className="overflow-x-auto flex-1 max-h-96 rounded-xl border border-[#E7ECF2]">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">#</th>
                  <th className="py-2.5 px-3 font-semibold">Description</th>
                  <th className="py-2.5 px-3 font-semibold text-right">
                    {productTab === 'revenue' ? 'Revenue ($)' : 'Units Sold'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E7ECF2] font-mono">
                {(productTab === 'revenue' ? topProductsRevenue : topProductsQuantity).map((p, i) => (
                  <tr key={i} className="hover:bg-[#F9FBFC] transition-colors">
                    <td className="py-2 px-3 text-[#98A2B3]">
                      <span className="w-5 h-5 rounded-full bg-[#F1F7FD] text-[#2867A8] inline-flex items-center justify-center text-[10px] font-bold">
                        {i + 1}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-sans font-medium text-[#243447] truncate max-w-xs" title={p.name}>
                      {p.name}
                    </td>
                    <td className="py-2 px-3 text-right font-semibold text-[#243447]">
                      {productTab === 'revenue'
                        ? `$${p.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                        : p.value.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Transaction Sample Table */}
      <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-[#243447]">Transaction Aggregation Sample (First 50 Invoices)</h3>
            <p className="text-xs text-[#667085]">
              Invoice-level aggregates detailing total units, unique items, and total basket price.
            </p>
          </div>
          <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#EAF4FF] text-[#2867A8] border border-[#CFE5FA]">
            Sample Window
          </span>
        </div>

        <div className="overflow-x-auto max-h-80 rounded-xl border border-[#E7ECF2]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
              <tr>
                <th className="py-2.5 px-3 font-semibold">InvoiceNo</th>
                <th className="py-2.5 px-3 font-semibold">CustomerID</th>
                <th className="py-2.5 px-3 font-semibold text-right">Quantity</th>
                <th className="py-2.5 px-3 font-semibold text-right">Unique Items</th>
                <th className="py-2.5 px-3 font-semibold text-right">Order Revenue ($)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E7ECF2] font-mono">
              {sampleTransactions.map(t => (
                <tr key={t.InvoiceNo} className="hover:bg-[#F9FBFC] transition-colors">
                  <td className="py-2 px-3 text-[#2867A8] font-semibold">{t.InvoiceNo}</td>
                  <td className="py-2 px-3 text-[#667085]">{t.CustomerID || <span className="text-[#98A2B3] italic">None</span>}</td>
                  <td className="py-2 px-3 text-right text-[#243447]">{t.Quantity.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right text-[#243447]">{t.UniqueProducts}</td>
                  <td className="py-2 px-3 text-right font-semibold text-[#287A50]">
                    ${t.Revenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
