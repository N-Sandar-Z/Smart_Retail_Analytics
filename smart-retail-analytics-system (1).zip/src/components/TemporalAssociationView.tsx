import React from 'react';
import { Play, Calendar, Clock, ArrowRight, CheckCircle2 } from 'lucide-react';
import { TemporalAssociationResult } from '../types';

interface TemporalAssociationViewProps {
  temporalResult: TemporalAssociationResult | null;
  onRunTemporal: () => void;
  isRunning: boolean;
  basketTransactionsCount: number;
}

export const TemporalAssociationView: React.FC<TemporalAssociationViewProps> = ({
  temporalResult,
  onRunTemporal,
  isRunning,
  basketTransactionsCount,
}) => {
  return (
    <div className="space-y-6">
      {/* View Header with Cyan Soft Accent */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-gradient-to-r from-[#E9F9FB] to-white p-6 rounded-2xl border border-[#C8ECEF] shadow-[0_4px_16px_rgba(30,60,90,0.04)]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#C8ECEF] text-[#287F89]">
              Sequential &amp; Longitudinal Mining
            </span>
            <span className="text-xs text-[#667085]">• Monthly FP-Growth</span>
          </div>
          <h2 className="text-xl font-bold text-[#243447] tracking-tight">Temporal Association Analysis</h2>
          <p className="text-xs text-[#667085] mt-1 max-w-2xl">
            Longitudinal monthly frequent pattern mining tracking product affinity shifts, seasonal bundle surges, and recurring purchase dynamics across calendar months.
          </p>
        </div>

        <button
          id="run-temporal-page-btn"
          onClick={onRunTemporal}
          disabled={isRunning || basketTransactionsCount === 0}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#54B9C5] hover:bg-[#43aab7] text-white font-medium text-xs shadow-sm transition disabled:opacity-50 cursor-pointer whitespace-nowrap"
        >
          {isRunning ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Mining Monthly Patterns...
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              Run Temporal Mining
            </>
          )}
        </button>
      </div>

      {/* KPI Cards in Cyan / Pastel styling */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#667085]">Active Baskets</span>
            <div className="w-8 h-8 rounded-xl bg-[#E9F9FB] flex items-center justify-center text-[#54B9C5]">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {basketTransactionsCount.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Multi-month transaction history</div>
        </div>

        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#287F89]">Temporal Rules</span>
            <div className="w-8 h-8 rounded-xl bg-[#E9F9FB] flex items-center justify-center text-[#54B9C5]">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#287F89] font-mono">
            {temporalResult ? temporalResult.rules.length.toLocaleString() : '—'}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Discovered across qualifying months</div>
        </div>

        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#667085]">Execution Time</span>
            <div className="w-8 h-8 rounded-xl bg-[#EAF8F0] flex items-center justify-center text-[#62B88A]">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-3xl font-bold text-[#243447] font-mono">
            {temporalResult ? `${temporalResult.executionTimeSeconds.toFixed(3)}s` : '—'}
          </div>
          <div className="mt-1 text-xs text-[#667085]">Optimized FP-Growth monthly iterations</div>
        </div>
      </div>

      {temporalResult ? (
        <div className="space-y-6">
          {/* Monthly Rule Counts and Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Months with Most Rules */}
            <div className="lg:col-span-4 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-[#243447]">Monthly Rule Density</h3>
                <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-[#E9F9FB] text-[#287F89] border border-[#C8ECEF]">
                  Top Months
                </span>
              </div>
              <p className="text-xs text-[#667085] mb-4">
                Monthly distribution showing shopping affinity concentration across calendar periods.
              </p>

              <div className="overflow-x-auto flex-1">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2]">
                    <tr>
                      <th className="py-2.5 px-3 font-semibold rounded-l-lg">Calendar Month</th>
                      <th className="py-2.5 px-3 font-semibold text-right rounded-r-lg">Rules Discovered</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E7ECF2] font-mono">
                    {temporalResult.monthlyRuleCounts.map(m => (
                      <tr key={m.YearMonth} className="hover:bg-[#F9FBFC]">
                        <td className="py-2.5 px-3 font-bold text-[#243447]">{m.YearMonth}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-[#287F89]">
                          <span className="inline-block px-2 py-0.5 rounded-md bg-[#E9F9FB] text-[#287F89] border border-[#C8ECEF]">
                            {m.count}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Longitudinal Insights Card */}
            <div className="lg:col-span-8 bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)] space-y-4">
              <div className="flex items-center justify-between border-b border-[#E7ECF2] pb-3">
                <h3 className="text-sm font-semibold text-[#243447]">Temporal Behavioral Insights</h3>
                <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-[#FFF8DB] text-[#8A6812] border border-[#F5E6A8]">
                  Dynamic Trends
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                <div className="p-3.5 rounded-xl bg-[#E9F9FB] border border-[#C8ECEF]">
                  <div className="text-xs font-bold text-[#287F89] mb-1">Persistent Staples</div>
                  <p className="text-[11px] text-[#243447] leading-relaxed">
                    Pairs appearing continuously across quarters represent evergreen cross-sell bundles unaffected by seasons.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-[#FFF1E5] border border-[#F6D6BC]">
                  <div className="text-xs font-bold text-[#A55D25] mb-1">Seasonal Surges</div>
                  <p className="text-[11px] text-[#243447] leading-relaxed">
                    Spikes in holiday and end-of-year months signify festive gift pairings and bundle gift sets.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-[#EAF8F0] border border-[#CBEBD9]">
                  <div className="text-xs font-bold text-[#287A50] mb-1">Velocity Shifts</div>
                  <p className="text-[11px] text-[#243447] leading-relaxed">
                    Newly emergent itemsets indicate shifting consumer taste and early catalog adoption.
                  </p>
                </div>
              </div>

              <div className="text-xs text-[#667085] bg-[#F7FAFC] p-3 rounded-xl border border-[#E7ECF2]">
                <strong className="text-[#243447]">Methodology Note:</strong> Each month is evaluated independently using FP-Growth with strict support &ge; 0.02 and confidence &ge; 0.30 filters. Only months with at least 20 transactions are ingested.
              </div>
            </div>
          </div>

          {/* Temporal Rules Table */}
          <div className="bg-white border border-[#E7ECF2] rounded-2xl p-5 shadow-[0_4px_16px_rgba(30,60,90,0.03)]">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
              <div>
                <h3 className="text-sm font-semibold text-[#243447]">
                  Discovered Temporal Association Rules ({temporalResult.rules.length} Total)
                </h3>
                <p className="text-xs text-[#667085]">
                  Showing chronological item associations grouped by active YearMonth period.
                </p>
              </div>
            </div>

            {temporalResult.rules.length > 0 ? (
              <div className="overflow-x-auto max-h-96 rounded-xl border border-[#E7ECF2]">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F7FAFC] text-[#475467] border-b border-[#E7ECF2] sticky top-0">
                    <tr>
                      <th className="py-2.5 px-3 font-semibold">Month</th>
                      <th className="py-2.5 px-3 font-semibold">Antecedent</th>
                      <th className="py-2.5 px-3 font-semibold text-center">Relationship</th>
                      <th className="py-2.5 px-3 font-semibold">Consequent</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Support</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Confidence</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Lift Ratio</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E7ECF2] font-mono">
                    {temporalResult.rules.map((r, i) => (
                      <tr key={i} className="hover:bg-[#F9FBFC]">
                        <td className="py-2 px-3 font-bold text-[#287F89] whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded-md bg-[#E9F9FB] text-[#287F89] border border-[#C8ECEF] text-[11px]">
                            {r.YearMonth}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-sans font-medium text-[#243447] max-w-xs truncate" title={r.Antecedent}>
                          {r.Antecedent}
                        </td>
                        <td className="py-2 px-3 text-center">
                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#E9F9FB] text-[#287F89]">
                            <ArrowRight className="w-3 h-3" />
                          </span>
                        </td>
                        <td className="py-2 px-3 font-sans font-medium text-[#287F89] max-w-xs truncate" title={r.Consequent}>
                          {r.Consequent}
                        </td>
                        <td className="py-2 px-3 text-right text-[#667085]">
                          {(r.support * 100).toFixed(2)}%
                        </td>
                        <td className="py-2 px-3 text-right text-[#667085]">
                          {(r.confidence * 100).toFixed(1)}%
                        </td>
                        <td className="py-2 px-3 text-right font-bold text-[#287A50]">
                          <span className="px-1.5 py-0.5 rounded bg-[#EAF8F0] text-[#287A50] border border-[#CBEBD9]">
                            {r.lift.toFixed(2)}x
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-6 bg-[#F7FAFC] border border-[#E7ECF2] rounded-xl text-center text-xs text-[#667085]">
                No temporal association rules met the support (&ge; 0.02) and confidence (&ge; 0.30) thresholds.
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white border border-[#E7ECF2] rounded-2xl p-12 text-center shadow-[0_4px_16px_rgba(30,60,90,0.03)] space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#E9F9FB] border border-[#C8ECEF] flex items-center justify-center mx-auto text-[#54B9C5]">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#243447]">Temporal Analysis Uncalculated</h3>
            <p className="text-xs text-[#667085] mt-1 max-w-md mx-auto">
              Run longitudinal monthly FP-Growth mining to uncover seasonal pattern trajectories and product affinities over time.
            </p>
          </div>
          <button
            onClick={onRunTemporal}
            disabled={isRunning || basketTransactionsCount === 0}
            className="px-5 py-2.5 rounded-xl bg-[#54B9C5] hover:bg-[#43aab7] text-white font-semibold text-xs shadow-sm transition disabled:opacity-50 cursor-pointer"
          >
            Compute Monthly FP-Growth Rules
          </button>
        </div>
      )}
    </div>
  );
};
