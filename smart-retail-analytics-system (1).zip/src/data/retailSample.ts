// Authentic multi-month retail benchmark dataset generator
// Matches the UCI Online Retail dataset format with exact columns

export function generateBenchmarkRetailCsv(): string {
  const products = [
    { code: '85123A', desc: 'WHITE HANGING HEART T-LIGHT HOLDER', price: 2.55, baseQty: 6 },
    { code: '71053', desc: 'WHITE METAL LANTERN', price: 3.39, baseQty: 4 },
    { code: '84406B', desc: 'CREAM CUPID HEARTS COAT HANGER', price: 2.75, baseQty: 8 },
    { code: '84029G', desc: 'KNITTED UNION FLAG HOT WATER BOTTLE', price: 3.39, baseQty: 6 },
    { code: '84029E', desc: 'RED WOOLLY HOTTIE WHITE HEART.', price: 3.39, baseQty: 6 },
    { code: '22752', desc: 'SET 7 BABUSHKA NESTING BOXES', price: 7.65, baseQty: 2 },
    { code: '21730', desc: 'GLASS STAR FROSTED T-LIGHT HOLDER', price: 4.25, baseQty: 6 },
    { code: '22633', desc: 'HAND WARMER UNION JACK', price: 1.85, baseQty: 12 },
    { code: '22632', desc: 'HAND WARMER RED RETROSPOT', price: 1.85, baseQty: 12 },
    { code: '22386', desc: 'JUMBO BAG PINK POLKADOT', price: 1.95, baseQty: 10 },
    { code: '85099B', desc: 'JUMBO BAG RED RETROSPOT', price: 1.95, baseQty: 15 },
    { code: '22382', desc: 'LUNCH BAG RED RETROSPOT', price: 1.65, baseQty: 10 },
    { code: '22383', desc: 'LUNCH BAG SUKI DESIGN', price: 1.65, baseQty: 10 },
    { code: '22384', desc: 'LUNCH BAG PINK POLKADOT', price: 1.65, baseQty: 10 },
    { code: '20725', desc: 'LUNCH BAG BLACK SKULL.', price: 1.65, baseQty: 10 },
    { code: '22720', desc: 'SET OF 3 CAKE TINS PANTRY DESIGN', price: 4.95, baseQty: 3 },
    { code: '22722', desc: 'SET OF 6 SPICE TINS PANTRY DESIGN', price: 3.75, baseQty: 4 },
    { code: '22960', desc: 'JAM MAKING SET WITH JARS', price: 4.25, baseQty: 6 },
    { code: '22961', desc: 'JAM MAKING SET PRINTED', price: 1.45, baseQty: 12 },
    { code: '22423', desc: 'REGENCY CAKESTAND 3 TIER', price: 10.95, baseQty: 2 },
    { code: '22457', desc: 'NATURAL SLATE HEART CHALKBOARD', price: 2.95, baseQty: 6 },
    { code: '22726', desc: 'ALARM CLOCK BAKELIKE GREEN', price: 3.75, baseQty: 4 },
    { code: '22727', desc: 'ALARM CLOCK BAKELIKE RED', price: 3.75, baseQty: 4 },
    { code: '22728', desc: 'ALARM CLOCK BAKELIKE PINK', price: 3.75, baseQty: 4 },
    { code: '22197', desc: 'POPCORN HOLDER', price: 0.85, baseQty: 36 },
    { code: '22086', desc: 'PAPER CHAIN KIT 50S CHRISTMAS', price: 2.55, baseQty: 10 },
  ];

  const countries = ['United Kingdom', 'Germany', 'France', 'EIRE', 'Spain', 'Netherlands', 'Belgium', 'Switzerland', 'Portugal', 'Australia'];
  const countryWeights = [0.80, 0.05, 0.04, 0.03, 0.02, 0.02, 0.01, 0.01, 0.01, 0.01];

  function pickCountry(r: number): string {
    let cum = 0;
    for (let i = 0; i < countries.length; i++) {
      cum += countryWeights[i];
      if (r <= cum) return countries[i];
    }
    return 'United Kingdom';
  }

  const lines: string[] = [
    'InvoiceNo,StockCode,Description,Quantity,InvoiceDate,UnitPrice,CustomerID,Country'
  ];

  let seed = 12345;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  // Generate continuous months from 2011-01 through 2011-10 (10 months)
  const months = [
    '2011-01', '2011-02', '2011-03', '2011-04', '2011-05',
    '2011-06', '2011-07', '2011-08', '2011-09', '2011-10'
  ];

  let invoiceCounter = 536365;

  for (let mIdx = 0; mIdx < months.length; mIdx++) {
    const ym = months[mIdx];
    // Invoices per month
    const invoiceCount = 70 + Math.floor(rand() * 40);

    for (let inv = 0; inv < invoiceCount; inv++) {
      invoiceCounter++;
      const isCancelled = rand() < 0.03; // 3% cancelled
      const invPrefix = isCancelled ? 'C' : '';
      const invoiceNo = `${invPrefix}${invoiceCounter}`;

      const day = 1 + Math.floor(rand() * 27);
      const hour = 8 + Math.floor(rand() * 11);
      const minute = Math.floor(rand() * 60);
      const invoiceDate = `${ym}-${String(day).padStart(2, '0')} ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:00`;

      const country = pickCountry(rand());
      // Customer ID (some missing ~ 10%)
      const hasCust = rand() > 0.10;
      const custIdNum = 12340 + Math.floor(rand() * 120);
      const customerId = hasCust ? String(custIdNum) : '';

      // Number of basket items: 1 to 6
      const basketSize = 1 + Math.floor(rand() * 5);
      const pickedProdIndices: number[] = [];

      // Affinity pairs:
      // Pair 1: ALARM CLOCK GREEN (idx 21) & ALARM CLOCK RED (idx 22)
      // Pair 2: JUMBO BAG RED (idx 10) & LUNCH BAG RED (idx 11)
      // Pair 3: HAND WARMER UNION JACK (idx 7) & HAND WARMER RED (idx 8)
      if (rand() < 0.35) {
        pickedProdIndices.push(21, 22);
      }
      if (rand() < 0.35) {
        pickedProdIndices.push(10, 11);
      }
      if (rand() < 0.30) {
        pickedProdIndices.push(7, 8);
      }

      while (pickedProdIndices.length < basketSize) {
        const pIdx = Math.floor(rand() * products.length);
        if (!pickedProdIndices.includes(pIdx)) {
          pickedProdIndices.push(pIdx);
        }
      }

      for (const pIdx of pickedProdIndices) {
        const prod = products[pIdx];
        const qty = isCancelled
          ? -(1 + Math.floor(rand() * prod.baseQty))
          : 1 + Math.floor(rand() * prod.baseQty * 2);

        lines.push(`${invoiceNo},"${prod.code}","${prod.desc}",${qty},"${invoiceDate}",${prod.price},"${customerId}","${country}"`);
      }
    }
  }

  // Add a duplicate line and an invalid date line to test data quality reporting
  lines.push('540001,"85123A","WHITE HANGING HEART T-LIGHT HOLDER",6,"2011-01-15 10:00:00",2.55,"12345","United Kingdom"');
  lines.push('540001,"85123A","WHITE HANGING HEART T-LIGHT HOLDER",6,"2011-01-15 10:00:00",2.55,"12345","United Kingdom"');
  lines.push('540002,"22423","REGENCY CAKESTAND 3 TIER",2,"INVALID_DATE_VALUE",10.95,"12346","United Kingdom"');

  return lines.join('\n');
}
