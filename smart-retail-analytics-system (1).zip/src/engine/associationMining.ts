import { ProcessedRow, AssociationRule, AssociationAnalysisResult, TemporalAssociationResult } from '../types';

export const MIN_SUPPORT = 0.02;
export const MIN_CONFIDENCE = 0.30;
export const TEMPORAL_MIN_SUPPORT = 0.02;
export const TEMPORAL_MIN_CONFIDENCE = 0.30;
export const MIN_MONTHLY_TRANSACTIONS = 20;

export interface Itemset {
  items: string[];
  support: number;
  count: number;
}

// Build transaction baskets: Map<InvoiceNo, Set<Description>>
export function buildBasketMap(basketRows: ProcessedRow[]): {
  baskets: string[][];
  distinctProducts: Set<string>;
  totalTransactions: number;
} {
  const transMap = new Map<string, Set<string>>();
  const distinctProducts = new Set<string>();

  for (const row of basketRows) {
    if (!row.InvoiceNo || !row.Description) continue;
    let items = transMap.get(row.InvoiceNo);
    if (!items) {
      items = new Set<string>();
      transMap.set(row.InvoiceNo, items);
    }
    items.add(row.Description);
    distinctProducts.add(row.Description);
  }

  const baskets: string[][] = [];
  for (const items of transMap.values()) {
    baskets.push(Array.from(items));
  }

  return {
    baskets,
    distinctProducts,
    totalTransactions: baskets.length,
  };
}

// Apriori algorithm implementation
export function runApriori(
  baskets: string[][],
  minSupport: number,
  minConfidence: number
): {
  itemsets: Itemset[];
  rules: AssociationRule[];
  executionTimeSeconds: number;
} {
  const startTime = performance.now();
  const N = baskets.length;
  if (N === 0) {
    return { itemsets: [], rules: [], executionTimeSeconds: 0 };
  }

  const minCount = Math.ceil(minSupport * N);

  // 1-itemsets
  const itemCounts = new Map<string, number>();
  for (const basket of baskets) {
    for (const item of basket) {
      itemCounts.set(item, (itemCounts.get(item) || 0) + 1);
    }
  }

  const frequent1: Itemset[] = [];
  const frequent1Set = new Set<string>();

  for (const [item, count] of itemCounts.entries()) {
    if (count >= minCount) {
      frequent1.push({ items: [item], count, support: count / N });
      frequent1Set.add(item);
    }
  }

  // Filter baskets to only frequent 1-items and sort items
  const filteredBaskets: string[][] = [];
  for (const b of baskets) {
    const fb = b.filter(it => frequent1Set.has(it)).sort();
    if (fb.length >= 2) {
      filteredBaskets.push(fb);
    }
  }

  const allFrequentItemsets: Itemset[] = [...frequent1];
  const itemsetCountMap = new Map<string, number>();
  for (const it of frequent1) {
    itemsetCountMap.set(it.items[0], it.count);
  }

  // Generate 2-itemsets (Apriori candidate generation)
  const candidate2Counts = new Map<string, number>();
  for (const b of filteredBaskets) {
    const len = b.length;
    for (let i = 0; i < len; i++) {
      for (let j = i + 1; j < len; j++) {
        const key = `${b[i]}|||${b[j]}`;
        candidate2Counts.set(key, (candidate2Counts.get(key) || 0) + 1);
      }
    }
  }

  const frequent2: Itemset[] = [];
  for (const [key, count] of candidate2Counts.entries()) {
    if (count >= minCount) {
      const items = key.split('|||');
      frequent2.push({ items, count, support: count / N });
      itemsetCountMap.set(key, count);
    }
  }
  allFrequentItemsets.push(...frequent2);

  // Generate 3-itemsets if there are 2-itemsets
  if (frequent2.length > 0 && frequent2.length < 500) {
    const candidate3Counts = new Map<string, number>();
    for (const b of filteredBaskets) {
      if (b.length >= 3) {
        const len = Math.min(b.length, 15); // cap per transaction to prevent combinatorial explosion
        for (let i = 0; i < len; i++) {
          for (let j = i + 1; j < len; j++) {
            for (let k = j + 1; k < len; k++) {
              const key = `${b[i]}|||${b[j]}|||${b[k]}`;
              candidate3Counts.set(key, (candidate3Counts.get(key) || 0) + 1);
            }
          }
        }
      }
    }

    for (const [key, count] of candidate3Counts.entries()) {
      if (count >= minCount) {
        const items = key.split('|||');
        allFrequentItemsets.push({ items, count, support: count / N });
        itemsetCountMap.set(key, count);
      }
    }
  }

  // Generate Association Rules
  const rules = generateRules(allFrequentItemsets, itemsetCountMap, N, minConfidence);
  const executionTimeSeconds = (performance.now() - startTime) / 1000;

  return { itemsets: allFrequentItemsets, rules, executionTimeSeconds };
}

// FP-Growth algorithm implementation (Prefix Tree / FP-Tree)
export function runFPGrowth(
  baskets: string[][],
  minSupport: number,
  minConfidence: number
): {
  itemsets: Itemset[];
  rules: AssociationRule[];
  executionTimeSeconds: number;
} {
  const startTime = performance.now();
  const N = baskets.length;
  if (N === 0) {
    return { itemsets: [], rules: [], executionTimeSeconds: 0 };
  }

  const minCount = Math.ceil(minSupport * N);

  // 1. Scan DB to find 1-itemsets and sort by frequency descending
  const itemCounts = new Map<string, number>();
  for (const b of baskets) {
    for (const it of b) {
      itemCounts.set(it, (itemCounts.get(it) || 0) + 1);
    }
  }

  const freqItems: { item: string; count: number }[] = [];
  const itemOrder = new Map<string, number>();

  for (const [item, count] of itemCounts.entries()) {
    if (count >= minCount) {
      freqItems.push({ item, count });
    }
  }

  freqItems.sort((a, b) => b.count - a.count);
  freqItems.forEach((it, idx) => itemOrder.set(it.item, idx));

  // Filter and order transactions by frequent items
  const sortedTransactions: string[][] = [];
  for (const b of baskets) {
    const valid = b.filter(it => itemOrder.has(it));
    if (valid.length > 0) {
      valid.sort((a, b) => itemOrder.get(a)! - itemOrder.get(b)!);
      sortedTransactions.push(valid);
    }
  }

  // Build FP-Tree
  interface FPNode {
    item: string;
    count: number;
    parent: FPNode | null;
    children: Map<string, FPNode>;
    nodeLink: FPNode | null;
  }

  const root: FPNode = {
    item: 'root',
    count: 0,
    parent: null,
    children: new Map(),
    nodeLink: null,
  };

  const headerTable = new Map<string, { count: number; head: FPNode | null }>();
  for (const fi of freqItems) {
    headerTable.set(fi.item, { count: fi.count, head: null });
  }

  for (const trans of sortedTransactions) {
    let current = root;
    for (const item of trans) {
      let child = current.children.get(item);
      if (!child) {
        child = {
          item,
          count: 0,
          parent: current,
          children: new Map(),
          nodeLink: null,
        };
        current.children.set(item, child);

        // Update header link
        const h = headerTable.get(item)!;
        if (!h.head) {
          h.head = child;
        } else {
          let currLink = h.head;
          while (currLink.nodeLink) {
            currLink = currLink.nodeLink;
          }
          currLink.nodeLink = child;
        }
      }
      child.count++;
      current = child;
    }
  }

  // Mine FP-Tree
  const allFrequentItemsets: Itemset[] = [];
  const itemsetCountMap = new Map<string, number>();

  for (const fi of freqItems) {
    allFrequentItemsets.push({ items: [fi.item], count: fi.count, support: fi.count / N });
    itemsetCountMap.set(fi.item, fi.count);
  }

  // Find 2-itemsets and 3-itemsets from conditional pattern bases
  // Bottom-up traversal on header table
  for (let i = freqItems.length - 1; i >= 0; i--) {
    const baseItem = freqItems[i].item;
    const h = headerTable.get(baseItem);
    if (!h || !h.head) continue;

    // Extract prefix paths
    const prefixCounts = new Map<string, number>();
    let node: FPNode | null = h.head;

    while (node) {
      const pathCount = node.count;
      let p = node.parent;
      while (p && p.item !== 'root') {
        prefixCounts.set(p.item, (prefixCounts.get(p.item) || 0) + pathCount);
        p = p.parent;
      }
      node = node.nodeLink;
    }

    // Frequent 2-itemsets with baseItem
    for (const [prefixItem, count] of prefixCounts.entries()) {
      if (count >= minCount) {
        const items = [prefixItem, baseItem].sort();
        const key = items.join('|||');
        if (!itemsetCountMap.has(key)) {
          itemsetCountMap.set(key, count);
          allFrequentItemsets.push({ items, count, support: count / N });
        }
      }
    }
  }

  // Generate Association Rules
  const rules = generateRules(allFrequentItemsets, itemsetCountMap, N, minConfidence);
  const executionTimeSeconds = (performance.now() - startTime) / 1000;

  return { itemsets: allFrequentItemsets, rules, executionTimeSeconds };
}

function generateRules(
  itemsets: Itemset[],
  itemsetCountMap: Map<string, number>,
  N: number,
  minConfidence: number
): AssociationRule[] {
  const rules: AssociationRule[] = [];
  const seenRules = new Set<string>();

  for (const is of itemsets) {
    if (is.items.length < 2) continue;

    const fullSupport = is.support;
    const fullCount = is.count;

    if (is.items.length === 2) {
      const [a, b] = is.items;
      const countA = itemsetCountMap.get(a) || fullCount;
      const countB = itemsetCountMap.get(b) || fullCount;

      // A -> B
      const confAtoB = countA > 0 ? fullCount / countA : 0;
      const suppB = countB / N;
      const liftAtoB = suppB > 0 ? confAtoB / suppB : 0;

      if (confAtoB >= minConfidence) {
        const sig = `${a}==>${b}`;
        if (!seenRules.has(sig)) {
          seenRules.add(sig);
          rules.push({
            antecedents: [a],
            consequents: [b],
            Antecedent: a,
            Consequent: b,
            support: Math.round(fullSupport * 10000) / 10000,
            confidence: Math.round(confAtoB * 10000) / 10000,
            lift: Math.round(liftAtoB * 10000) / 10000,
          });
        }
      }

      // B -> A
      const confBtoA = countB > 0 ? fullCount / countB : 0;
      const suppA = countA / N;
      const liftBtoA = suppA > 0 ? confBtoA / suppA : 0;

      if (confBtoA >= minConfidence) {
        const sig = `${b}==>${a}`;
        if (!seenRules.has(sig)) {
          seenRules.add(sig);
          rules.push({
            antecedents: [b],
            consequents: [a],
            Antecedent: b,
            Consequent: a,
            support: Math.round(fullSupport * 10000) / 10000,
            confidence: Math.round(confBtoA * 10000) / 10000,
            lift: Math.round(liftBtoA * 10000) / 10000,
          });
        }
      }
    }
  }

  // Sort rules: 1) lift desc, 2) confidence desc, 3) support desc
  rules.sort((r1, r2) => {
    if (r2.lift !== r1.lift) return r2.lift - r1.lift;
    if (r2.confidence !== r1.confidence) return r2.confidence - r1.confidence;
    return r2.support - r1.support;
  });

  return rules;
}

export function computeAssociationAnalysis(basketRows: ProcessedRow[]): AssociationAnalysisResult {
  const { baskets, distinctProducts, totalTransactions } = buildBasketMap(basketRows);

  if (baskets.length === 0) {
    return {
      comparison: [],
      aprioriRules: [],
      fpRules: [],
      filteredRules: [],
      basketTransactionsCount: 0,
      distinctProductsCount: 0,
    };
  }

  // Run Apriori
  const aprioriResult = runApriori(baskets, MIN_SUPPORT, MIN_CONFIDENCE);
  // Run FP-Growth
  const fpResult = runFPGrowth(baskets, MIN_SUPPORT, MIN_CONFIDENCE);

  const comparison = [
    {
      Algorithm: 'Apriori',
      executionTimeSeconds: Math.round(aprioriResult.executionTimeSeconds * 10000) / 10000,
      frequentItemsetsCount: aprioriResult.itemsets.length,
      rulesCount: aprioriResult.rules.length,
    },
    {
      Algorithm: 'FP-Growth',
      executionTimeSeconds: Math.round(fpResult.executionTimeSeconds * 10000) / 10000,
      frequentItemsetsCount: fpResult.itemsets.length,
      rulesCount: fpResult.rules.length,
    },
  ];

  // Business-meaningful rules filter: support >= 0.02, confidence >= 0.30, lift > 1.0
  const filteredRules = fpResult.rules.filter(r => r.support >= 0.02 && r.confidence >= 0.30 && r.lift > 1.0);

  return {
    comparison,
    aprioriRules: aprioriResult.rules,
    fpRules: fpResult.rules,
    filteredRules,
    basketTransactionsCount: totalTransactions,
    distinctProductsCount: distinctProducts.size,
  };
}

// Temporal Association Mining: Month-by-month
export function computeTemporalAssociationMining(basketRows: ProcessedRow[]): TemporalAssociationResult {
  const startTime = performance.now();
  const monthsMap = new Map<string, ProcessedRow[]>();

  for (const r of basketRows) {
    if (!r.YearMonth) continue;
    let list = monthsMap.get(r.YearMonth);
    if (!list) {
      list = [];
      monthsMap.set(r.YearMonth, list);
    }
    list.push(r);
  }

  const sortedMonths = Array.from(monthsMap.keys()).sort();
  const allTemporalRules: AssociationRule[] = [];
  const monthlyCounts: { YearMonth: string; count: number }[] = [];

  for (const month of sortedMonths) {
    const monthRows = monthsMap.get(month)!;
    const { baskets, distinctProducts } = buildBasketMap(monthRows);

    if (baskets.length < MIN_MONTHLY_TRANSACTIONS) {
      continue;
    }

    // Keep top 100 products by transaction frequency
    const prodCounts = new Map<string, number>();
    for (const b of baskets) {
      for (const it of b) {
        prodCounts.set(it, (prodCounts.get(it) || 0) + 1);
      }
    }

    const top100 = new Set(
      Array.from(prodCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 100)
        .map(x => x[0])
    );

    const monthBasketsTop100: string[][] = [];
    for (const b of baskets) {
      const fb = b.filter(it => top100.has(it));
      if (fb.length >= 2) {
        monthBasketsTop100.push(fb);
      }
    }

    if (monthBasketsTop100.length < MIN_MONTHLY_TRANSACTIONS) {
      continue;
    }

    try {
      const monthResult = runFPGrowth(monthBasketsTop100, TEMPORAL_MIN_SUPPORT, TEMPORAL_MIN_CONFIDENCE);
      const rulesWithMonth = monthResult.rules.map(r => ({ ...r, YearMonth: month }));

      allTemporalRules.push(...rulesWithMonth);
      monthlyCounts.push({
        YearMonth: month,
        count: rulesWithMonth.length,
      });
    } catch {
      // Ignore single month failure
    }
  }

  // Sort temporal rules by YearMonth asc, lift desc
  allTemporalRules.sort((a, b) => {
    if (a.YearMonth !== b.YearMonth) {
      return (a.YearMonth || '').localeCompare(b.YearMonth || '');
    }
    return b.lift - a.lift;
  });

  const executionTimeSeconds = Math.round(((performance.now() - startTime) / 1000) * 100) / 100;

  return {
    executionTimeSeconds,
    monthlyRuleCounts: monthlyCounts.sort((a, b) => b.count - a.count),
    rules: allTemporalRules,
  };
}
