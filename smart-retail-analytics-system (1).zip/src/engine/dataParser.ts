import Papa from 'papaparse';
import { RawRetailRow, ProcessedRow, PreparedData, DataQualityMetrics } from '../types';

export const REQUIRED_COLUMNS = [
  'InvoiceNo',
  'StockCode',
  'Description',
  'Quantity',
  'InvoiceDate',
  'UnitPrice',
  'CustomerID',
  'Country',
];

const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export function validateColumns(headers: string[]): void {
  const normalizedHeaders = headers.map(h => h.trim());
  const missing = REQUIRED_COLUMNS.filter(req => 
    !normalizedHeaders.some(h => h.toLowerCase() === req.toLowerCase())
  );
  if (missing.length > 0) {
    throw new Error(`Missing required columns: ${missing.join(', ')}`);
  }
}

export function parseDate(dateStr: string): Date | null {
  if (!dateStr) return null;
  const trimmed = String(dateStr).trim();
  if (!trimmed) return null;

  // Try standard Date.parse
  const timestamp = Date.parse(trimmed);
  if (!isNaN(timestamp)) {
    const d = new Date(timestamp);
    if (!isNaN(d.getTime())) return d;
  }

  // Common retail formats: "DD/MM/YYYY HH:mm" or "MM/DD/YYYY HH:mm" or "YYYY-MM-DD HH:mm:ss"
  const parts = trimmed.split(/[\sT]+/);
  const datePart = parts[0];
  const timePart = parts[1] || '00:00:00';

  const dateSub = datePart.split(/[-/.]/);
  const timeSub = timePart.split(':');

  if (dateSub.length === 3) {
    let year = parseInt(dateSub[0], 10);
    let month = parseInt(dateSub[1], 10);
    let day = parseInt(dateSub[2], 10);

    // If day or month might be first (e.g. DD/MM/YYYY or MM/DD/YYYY)
    if (year < 1000 && dateSub[2].length === 4) {
      year = parseInt(dateSub[2], 10);
      month = parseInt(dateSub[0], 10);
      day = parseInt(dateSub[1], 10);
      if (month > 12 && day <= 12) {
        // Swap if month > 12 (DD/MM/YYYY)
        const tmp = month;
        month = day;
        day = tmp;
      }
    }

    const hours = timeSub[0] ? parseInt(timeSub[0], 10) : 0;
    const minutes = timeSub[1] ? parseInt(timeSub[1], 10) : 0;
    const seconds = timeSub[2] ? parseInt(timeSub[2], 10) : 0;

    const reconstructed = new Date(year, month - 1, day, hours, minutes, seconds);
    if (!isNaN(reconstructed.getTime())) {
      return reconstructed;
    }
  }

  return null;
}

export function parseCsvContent(csvString: string): PreparedData {
  const parseResult = Papa.parse<Record<string, any>>(csvString, {
    header: true,
    skipEmptyLines: 'greedy',
    dynamicTyping: false,
  });

  if (parseResult.errors && parseResult.errors.length > 0 && (!parseResult.data || parseResult.data.length === 0)) {
    throw new Error(`CSV Parsing Error: ${parseResult.errors[0].message}`);
  }

  const rawData = parseResult.data;
  if (!rawData || rawData.length === 0) {
    throw new Error('The uploaded CSV file is empty.');
  }

  const headers = parseResult.meta.fields || Object.keys(rawData[0]);
  validateColumns(headers);

  // Map header variations to exact keys
  const headerMap: Record<string, string> = {};
  for (const h of headers) {
    const lower = h.trim().toLowerCase();
    for (const req of REQUIRED_COLUMNS) {
      if (lower === req.toLowerCase()) {
        headerMap[req] = h;
      }
    }
  }

  let invalidDatesCount = 0;
  let cancelledRowsCount = 0;
  let missingCustomerCount = 0;
  let duplicateCount = 0;

  const rawRows: RawRetailRow[] = [];
  const processedRows: ProcessedRow[] = [];
  const salesRows: ProcessedRow[] = [];
  const customerRows: ProcessedRow[] = [];
  const basketRows: ProcessedRow[] = [];

  // Track duplicates using a hash set of line signature
  const seenSignatures = new Set<string>();

  for (let i = 0; i < rawData.length; i++) {
    const row = rawData[i];
    const invoiceNoRaw = String(row[headerMap['InvoiceNo']] ?? '').trim();
    const stockCodeRaw = String(row[headerMap['StockCode']] ?? '').trim();
    const descriptionRaw = String(row[headerMap['Description']] ?? '').trim();
    const quantityRaw = parseFloat(row[headerMap['Quantity']]);
    const invoiceDateRaw = String(row[headerMap['InvoiceDate']] ?? '').trim();
    const unitPriceRaw = parseFloat(row[headerMap['UnitPrice']]);
    const customerIdRaw = row[headerMap['CustomerID']] !== undefined && row[headerMap['CustomerID']] !== null
      ? String(row[headerMap['CustomerID']]).trim()
      : '';
    const countryRaw = String(row[headerMap['Country']] ?? '').trim();

    if (!invoiceNoRaw && !stockCodeRaw && isNaN(quantityRaw)) {
      continue;
    }

    // Check duplicate
    const signature = `${invoiceNoRaw}|${stockCodeRaw}|${quantityRaw}|${invoiceDateRaw}|${unitPriceRaw}|${customerIdRaw}`;
    if (seenSignatures.has(signature)) {
      duplicateCount++;
    } else {
      seenSignatures.add(signature);
    }

    if (!customerIdRaw || customerIdRaw === 'NaN' || customerIdRaw === 'null') {
      missingCustomerCount++;
    }

    const isCancelled = invoiceNoRaw.toUpperCase().startsWith('C');
    if (isCancelled) {
      cancelledRowsCount++;
    }

    const parsedDate = parseDate(invoiceDateRaw);
    if (!parsedDate) {
      invalidDatesCount++;
      continue; // drop row with invalid date from subsequent sets as per notebook
    }

    const quantity = isNaN(quantityRaw) ? 0 : quantityRaw;
    const unitPrice = isNaN(unitPriceRaw) ? 0 : unitPriceRaw;
    const revenue = quantity * unitPrice;

    const year = parsedDate.getFullYear();
    const month = parsedDate.getMonth() + 1; // 1-12
    const yearMonth = `${year}-${String(month).padStart(2, '0')}`;
    const day = parsedDate.getDate();
    // Python dt.dayofweek: Monday is 0, Sunday is 6
    const jsDay = parsedDate.getDay(); // 0 is Sunday, 1 is Monday
    const dayOfWeek = (jsDay + 6) % 7;
    const dayName = DAY_NAMES[dayOfWeek];
    const hour = parsedDate.getHours();
    const isWeekend = dayOfWeek >= 5;

    const processed: ProcessedRow = {
      InvoiceNo: invoiceNoRaw,
      StockCode: stockCodeRaw,
      Description: descriptionRaw,
      Quantity: quantity,
      InvoiceDate: parsedDate,
      UnitPrice: unitPrice,
      CustomerID: customerIdRaw && customerIdRaw !== 'NaN' && customerIdRaw !== 'null' ? customerIdRaw : '',
      Country: countryRaw || 'Unspecified',
      Year: year,
      Month: month,
      YearMonth: yearMonth,
      Day: day,
      DayOfWeek: dayOfWeek,
      DayName: dayName,
      Hour: hour,
      IsWeekend: isWeekend,
      Revenue: revenue,
    };

    rawRows.push({
      InvoiceNo: invoiceNoRaw,
      StockCode: stockCodeRaw,
      Description: descriptionRaw,
      Quantity: quantity,
      InvoiceDate: invoiceDateRaw,
      UnitPrice: unitPrice,
      CustomerID: customerIdRaw,
      Country: countryRaw,
    });

    processedRows.push(processed);

    // Filter sales_df: Quantity > 0, UnitPrice > 0, not cancelled
    if (quantity > 0 && unitPrice > 0 && !isCancelled) {
      salesRows.push(processed);

      // Customer dataset: sales with non-null CustomerID
      if (processed.CustomerID !== '') {
        customerRows.push(processed);
      }

      // Basket dataset: valid sales records with non-null InvoiceNo, StockCode, and non-empty Description
      if (processed.InvoiceNo && processed.StockCode && processed.Description.length > 0) {
        basketRows.push(processed);
      }
    }
  }

  // Calculate quality metrics
  const uniqueCustomerSet = new Set<string>();
  for (const r of customerRows) {
    uniqueCustomerSet.add(r.CustomerID);
  }

  const uniqueInvoiceSet = new Set<string>();
  let totalRevenue = 0;
  let minDate = new Date(8640000000000000);
  let maxDate = new Date(-8640000000000000);

  for (const r of salesRows) {
    uniqueInvoiceSet.add(r.InvoiceNo);
    totalRevenue += r.Revenue;
    if (r.InvoiceDate < minDate) minDate = r.InvoiceDate;
    if (r.InvoiceDate > maxDate) maxDate = r.InvoiceDate;
  }

  const quality: DataQualityMetrics = {
    rawRows: rawRows.length,
    salesRows: salesRows.length,
    uniqueCustomers: uniqueCustomerSet.size,
    validTransactions: uniqueInvoiceSet.size,
    totalRevenue: Math.round(totalRevenue * 100) / 100,
    dateRange: {
      start: minDate.getTime() <= maxDate.getTime() ? minDate.toISOString().slice(0, 10) : 'N/A',
      end: minDate.getTime() <= maxDate.getTime() ? maxDate.toISOString().slice(0, 10) : 'N/A',
    },
    missingCustomerRows: missingCustomerCount,
    cancelledRows: cancelledRowsCount,
    duplicateRows: duplicateCount,
    invalidDates: invalidDatesCount,
  };

  return {
    rawRows,
    salesRows,
    customerRows,
    basketRows,
    quality,
  };
}
