import { ProcessedRow, MLModelResult, PredictionOutputRow, PredictiveAnalysisState } from '../types';

export const FEATURE_COLUMNS = [
  'Quantity_Lag_1',
  'Quantity_Lag_2',
  'Quantity_Lag_3',
  'Quantity_Rolling_3M',
  'Quantity_Rolling_6M',
  'Revenue_Lag_1',
  'Revenue_Rolling_3M',
  'Revenue_Rolling_6M',
  'Quantity_Growth_1M',
  'Revenue_Growth_1M',
  'Invoice_Count_Lag_1',
  'Customer_Count_Lag_1',
  'Average_Price_Lag_1',
  'Month_Number',
  'Quarter',
];

export const BEST_SELLER_PERCENTILE = 0.80;
export const K_FEATURES = 10;

export interface MLRow {
  StockCode: string;
  Description?: string;
  YearMonth: string;
  NextMonth?: string;
  features: Record<string, number>;
  Target: number;
}

// Add 1 calendar month to "YYYY-MM"
export function addCalendarMonth(yearMonth: string, count: number = 1): string {
  const [yStr, mStr] = yearMonth.split('-');
  let year = parseInt(yStr, 10);
  let month = parseInt(mStr, 10) + count;
  while (month > 12) {
    month -= 12;
    year += 1;
  }
  while (month < 1) {
    month += 12;
    year -= 1;
  }
  return `${year}-${String(month).padStart(2, '0')}`;
}

// 80th percentile computation
function calculatePercentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const index = p * (sorted.length - 1);
  const lower = Math.floor(index);
  const upper = Math.ceil(index);
  const weight = index - lower;
  return sorted[lower] * (1 - weight) + sorted[upper] * weight;
}

export function buildMLDataset(salesRows: ProcessedRow[]): {
  modelRows: MLRow[];
  productDescriptions: Map<string, string>;
} {
  // 1. Group by (StockCode, YearMonth)
  interface ProductMonthAgg {
    StockCode: string;
    YearMonth: string;
    Monthly_Quantity: number;
    Monthly_Revenue: number;
    unitPrices: number[];
    invoices: Set<string>;
    customers: Set<string>;
  }

  const aggMap = new Map<string, ProductMonthAgg>();
  const productDescriptions = new Map<string, string>();

  for (const r of salesRows) {
    if (!productDescriptions.has(r.StockCode) && r.Description) {
      productDescriptions.set(r.StockCode, r.Description);
    }

    const key = `${r.StockCode}|||${r.YearMonth}`;
    let entry = aggMap.get(key);
    if (!entry) {
      entry = {
        StockCode: r.StockCode,
        YearMonth: r.YearMonth,
        Monthly_Quantity: 0,
        Monthly_Revenue: 0,
        unitPrices: [],
        invoices: new Set(),
        customers: new Set(),
      };
      aggMap.set(key, entry);
    }
    entry.Monthly_Quantity += r.Quantity;
    entry.Monthly_Revenue += r.Revenue;
    entry.unitPrices.push(r.UnitPrice);
    entry.invoices.add(r.InvoiceNo);
    if (r.CustomerID) {
      entry.customers.add(r.CustomerID);
    }
  }

  // Organize by StockCode
  const productHistory = new Map<
    string,
    {
      YearMonth: string;
      Monthly_Quantity: number;
      Monthly_Revenue: number;
      Average_Unit_Price: number;
      Invoice_Count: number;
      Customer_Count: number;
    }[]
  >();

  for (const entry of aggMap.values()) {
    const avgPrice =
      entry.unitPrices.length > 0
        ? entry.unitPrices.reduce((a, b) => a + b, 0) / entry.unitPrices.length
        : 0;

    let list = productHistory.get(entry.StockCode);
    if (!list) {
      list = [];
      productHistory.set(entry.StockCode, list);
    }
    list.push({
      YearMonth: entry.YearMonth,
      Monthly_Quantity: entry.Monthly_Quantity,
      Monthly_Revenue: entry.Monthly_Revenue,
      Average_Unit_Price: avgPrice,
      Invoice_Count: entry.invoices.size,
      Customer_Count: entry.customers.size,
    });
  }

  // Sort each product's monthly records by YearMonth
  for (const list of productHistory.values()) {
    list.sort((a, b) => a.YearMonth.localeCompare(b.YearMonth));
  }

  // First pass: identify NextMonth_Quantity for valid next calendar months
  interface CandidateRow {
    StockCode: string;
    YearMonth: string;
    NextMonth: string;
    Valid_Next_Month: boolean;
    NextMonth_Quantity: number;
    itemHistory: {
      Monthly_Quantity: number;
      Monthly_Revenue: number;
      Average_Unit_Price: number;
      Invoice_Count: number;
      Customer_Count: number;
      YearMonth: string;
    }[];
    currentIndex: number;
  }

  const candidateRows: CandidateRow[] = [];
  const nextMonthQuantities = new Map<string, number[]>();

  for (const [stockCode, history] of productHistory.entries()) {
    for (let i = 0; i < history.length; i++) {
      const current = history[i];
      const expectedNextMonth = addCalendarMonth(current.YearMonth, 1);

      let validNext = false;
      let nextQty = 0;

      if (i + 1 < history.length) {
        const nextRecord = history[i + 1];
        if (nextRecord.YearMonth === expectedNextMonth) {
          validNext = true;
          nextQty = nextRecord.Monthly_Quantity;
        }
      }

      if (validNext) {
        candidateRows.push({
          StockCode: stockCode,
          YearMonth: current.YearMonth,
          NextMonth: expectedNextMonth,
          Valid_Next_Month: true,
          NextMonth_Quantity: nextQty,
          itemHistory: history,
          currentIndex: i,
        });

        let qList = nextMonthQuantities.get(expectedNextMonth);
        if (!qList) {
          qList = [];
          nextMonthQuantities.set(expectedNextMonth, qList);
        }
        qList.push(nextQty);
      }
    }
  }

  // 80th percentile threshold per NextMonth
  const monthlyThresholds = new Map<string, number>();
  for (const [nm, qList] of nextMonthQuantities.entries()) {
    monthlyThresholds.set(nm, calculatePercentile(qList, BEST_SELLER_PERCENTILE));
  }

  // Build MLRows with historical features
  const modelRows: MLRow[] = [];

  for (const cand of candidateRows) {
    const threshold = monthlyThresholds.get(cand.NextMonth);
    if (threshold === undefined) continue;

    const isBestSeller = cand.NextMonth_Quantity >= threshold ? 1 : 0;
    const history = cand.itemHistory;
    const i = cand.currentIndex;

    // Must have at least 1 past month for lag 1
    // Lags are based on strictly past months:
    // Quantity_Lag_1 = history[i-1], Quantity_Lag_2 = history[i-2], etc.
    // In the notebook: product_month is aggregated by month.
    // grouped['Monthly_Quantity'].shift(1) refers to the previous row for that product.
    if (i < 1) continue; // Needs at least 1 previous month for lag features

    const lag1 = history[i - 1];
    const lag2 = i >= 2 ? history[i - 2] : null;
    const lag3 = i >= 3 ? history[i - 3] : null;

    // Rolling 3M: mean of shifted 1, 2, 3 (if available)
    const rolling3Q = [lag1.Monthly_Quantity];
    const rolling3R = [lag1.Monthly_Revenue];
    if (lag2) {
      rolling3Q.push(lag2.Monthly_Quantity);
      rolling3R.push(lag2.Monthly_Revenue);
    }
    if (lag3) {
      rolling3Q.push(lag3.Monthly_Quantity);
      rolling3R.push(lag3.Monthly_Revenue);
    }

    const rolling6Q = [...rolling3Q];
    const rolling6R = [...rolling3R];
    for (let k = 4; k <= 6; k++) {
      if (i >= k) {
        rolling6Q.push(history[i - k].Monthly_Quantity);
        rolling6R.push(history[i - k].Monthly_Revenue);
      }
    }

    const qLag1 = lag1.Monthly_Quantity;
    const qLag2 = lag2 ? lag2.Monthly_Quantity : qLag1;
    const qLag3 = lag3 ? lag3.Monthly_Quantity : qLag2;

    const rLag1 = lag1.Monthly_Revenue;
    const rLag2 = lag2 ? lag2.Monthly_Revenue : rLag1;

    const qRolling3 = rolling3Q.reduce((a, b) => a + b, 0) / rolling3Q.length;
    const qRolling6 = rolling6Q.reduce((a, b) => a + b, 0) / rolling6Q.length;

    const rRolling3 = rolling3R.reduce((a, b) => a + b, 0) / rolling3R.length;
    const rRolling6 = rolling6R.reduce((a, b) => a + b, 0) / rolling6R.length;

    const qGrowth1M = qLag2 !== 0 ? (qLag1 / qLag2) - 1 : 0;
    const rGrowth1M = rLag2 !== 0 ? (rLag1 / rLag2) - 1 : 0;

    const invCountLag1 = lag1.Invoice_Count;
    const custCountLag1 = lag1.Customer_Count;
    const avgPriceLag1 = lag1.Average_Unit_Price;

    const parts = cand.YearMonth.split('-');
    const monthNum = parseInt(parts[1], 10);
    const quarter = Math.ceil(monthNum / 3);

    const featureObj: Record<string, number> = {
      Quantity_Lag_1: qLag1,
      Quantity_Lag_2: qLag2,
      Quantity_Lag_3: qLag3,
      Quantity_Rolling_3M: qRolling3,
      Quantity_Rolling_6M: qRolling6,
      Revenue_Lag_1: rLag1,
      Revenue_Rolling_3M: rRolling3,
      Revenue_Rolling_6M: rRolling6,
      Quantity_Growth_1M: isFinite(qGrowth1M) ? qGrowth1M : 0,
      Revenue_Growth_1M: isFinite(rGrowth1M) ? rGrowth1M : 0,
      Invoice_Count_Lag_1: invCountLag1,
      Customer_Count_Lag_1: custCountLag1,
      Average_Price_Lag_1: avgPriceLag1,
      Month_Number: monthNum,
      Quarter: quarter,
    };

    // Verify all 15 features are finite numbers
    let allValid = true;
    for (const feat of FEATURE_COLUMNS) {
      if (featureObj[feat] === undefined || isNaN(featureObj[feat]) || !isFinite(featureObj[feat])) {
        allValid = false;
        break;
      }
    }

    if (allValid) {
      modelRows.push({
        StockCode: cand.StockCode,
        Description: productDescriptions.get(cand.StockCode) || cand.StockCode,
        YearMonth: cand.YearMonth,
        NextMonth: cand.NextMonth,
        features: featureObj,
        Target: isBestSeller,
      });
    }
  }

  return { modelRows, productDescriptions };
}

// Time-based split: first 80% unique months -> training, final 20% -> testing
export function makeTimeSplit(modelRows: MLRow[]): {
  trainRows: MLRow[];
  testRows: MLRow[];
  trainPeriod: { start: string; end: string };
  testPeriod: { start: string; end: string };
} {
  const sorted = [...modelRows].sort((a, b) => a.YearMonth.localeCompare(b.YearMonth));
  const uniqueMonths = Array.from(new Set(sorted.map(r => r.YearMonth))).sort();

  if (uniqueMonths.length < 2) {
    // If only 1 month, split rows 80/20
    const splitIdx = Math.max(1, Math.floor(sorted.length * 0.8));
    return {
      trainRows: sorted.slice(0, splitIdx),
      testRows: sorted.slice(splitIdx),
      trainPeriod: { start: uniqueMonths[0] || 'N/A', end: uniqueMonths[0] || 'N/A' },
      testPeriod: { start: uniqueMonths[0] || 'N/A', end: uniqueMonths[0] || 'N/A' },
    };
  }

  let splitIndex = Math.floor(uniqueMonths.length * 0.80);
  splitIndex = Math.min(Math.max(splitIndex, 1), uniqueMonths.length - 1);

  const trainMonths = new Set(uniqueMonths.slice(0, splitIndex));
  const testMonths = new Set(uniqueMonths.slice(splitIndex));

  const trainRows = sorted.filter(r => trainMonths.has(r.YearMonth));
  const testRows = sorted.filter(r => testMonths.has(r.YearMonth));

  return {
    trainRows,
    testRows,
    trainPeriod: { start: uniqueMonths[0], end: uniqueMonths[splitIndex - 1] },
    testPeriod: { start: uniqueMonths[splitIndex], end: uniqueMonths[uniqueMonths.length - 1] },
  };
}

// Mutual Information feature selection (SelectKBest mutual_info_classif)
export function computeMutualInformation(
  trainRows: MLRow[],
  kBest: number = K_FEATURES
): {
  selectedColumns: string[];
  featureScores: { Feature: string; Score: number; Selected: boolean }[];
} {
  const N = trainRows.length;
  if (N === 0) {
    return { selectedColumns: FEATURE_COLUMNS.slice(0, kBest), featureScores: [] };
  }

  // Count target classes
  let count0 = 0;
  let count1 = 0;
  for (const r of trainRows) {
    if (r.Target === 1) count1++;
    else count0++;
  }

  const pY0 = count0 / N;
  const pY1 = count1 / N;
  // Shannon entropy of Y
  const H_Y = (pY0 > 0 ? -pY0 * Math.log2(pY0) : 0) + (pY1 > 0 ? -pY1 * Math.log2(pY1) : 0);

  const scores: { Feature: string; Score: number }[] = [];

  for (const feat of FEATURE_COLUMNS) {
    // Discretize feature into 5 quantile bins for mutual information estimation
    const values = trainRows.map(r => r.features[feat]);
    const sortedVal = [...values].sort((a, b) => a - b);

    const numBins = Math.min(5, Math.max(2, Math.floor(N / 10)));
    const binCuts: number[] = [];
    for (let b = 1; b < numBins; b++) {
      binCuts.push(sortedVal[Math.floor((b / numBins) * sortedVal.length)]);
    }

    const getBin = (v: number) => {
      for (let b = 0; b < binCuts.length; b++) {
        if (v <= binCuts[b]) return b;
      }
      return binCuts.length;
    };

    // Joint counts: [bin][target]
    const totalBins = binCuts.length + 1;
    const jointCounts = Array.from({ length: totalBins }, () => [0, 0]);
    const binCounts = new Array(totalBins).fill(0);

    for (let i = 0; i < N; i++) {
      const b = getBin(values[i]);
      const t = trainRows[i].Target === 1 ? 1 : 0;
      jointCounts[b][t]++;
      binCounts[b]++;
    }

    // Conditional entropy H(Y|X)
    let H_Y_given_X = 0;
    for (let b = 0; b < totalBins; b++) {
      const binN = binCounts[b];
      if (binN > 0) {
        const p0 = jointCounts[b][0] / binN;
        const p1 = jointCounts[b][1] / binN;
        const hBin = (p0 > 0 ? -p0 * Math.log2(p0) : 0) + (p1 > 0 ? -p1 * Math.log2(p1) : 0);
        H_Y_given_X += (binN / N) * hBin;
      }
    }

    const mi = Math.max(0, H_Y - H_Y_given_X);
    scores.push({ Feature: feat, Score: Math.round(mi * 10000) / 10000 });
  }

  scores.sort((a, b) => b.Score - a.Score);

  const selectedSet = new Set(scores.slice(0, kBest).map(s => s.Feature));
  const featureScores = scores.map(s => ({
    Feature: s.Feature,
    Score: s.Score,
    Selected: selectedSet.has(s.Feature),
  }));

  const selectedColumns = featureScores.filter(f => f.Selected).map(f => f.Feature);

  return { selectedColumns, featureScores };
}

// -------------------------------------------------------------
// Model Implementations (Strictly Equal Class Weights {0:1, 1:1})
// -------------------------------------------------------------

function sigmoid(z: number): number {
  if (z >= 40) return 1;
  if (z <= -40) return 0;
  return 1 / (1 + Math.exp(-z));
}

// 1. Logistic Regression
export function trainLogisticRegression(
  trainRows: MLRow[],
  testRows: MLRow[],
  selectedFeatures: string[]
): {
  predictions: number[];
  probabilities: number[];
  accuracy: number;
  confusionMatrix: [[number, number], [number, number]];
  trainTimeSeconds: number;
} {
  const startTime = performance.now();
  const d = selectedFeatures.length;
  const nTrain = trainRows.length;

  // Compute mean and std for feature scaling (StandardScaler)
  const means = new Array(d).fill(0);
  for (const r of trainRows) {
    for (let j = 0; j < d; j++) {
      means[j] += r.features[selectedFeatures[j]];
    }
  }
  for (let j = 0; j < d; j++) means[j] /= nTrain;

  const stds = new Array(d).fill(0);
  for (const r of trainRows) {
    for (let j = 0; j < d; j++) {
      stds[j] += (r.features[selectedFeatures[j]] - means[j]) ** 2;
    }
  }
  for (let j = 0; j < d; j++) {
    stds[j] = Math.sqrt(stds[j] / nTrain) || 1;
  }

  // Standardize training data
  const XTrain: number[][] = trainRows.map(r =>
    selectedFeatures.map((f, j) => (r.features[f] - means[j]) / stds[j])
  );
  const yTrain = trainRows.map(r => r.Target);

  // Gradient Descent with equal class weights (class_weight={0: 1, 1: 1})
  const weights = new Array(d).fill(0);
  let bias = 0;
  const lr = 0.05;
  const epochs = 300;
  const lambdaL2 = 0.001;

  for (let ep = 0; ep < epochs; ep++) {
    const gradW = new Array(d).fill(0);
    let gradB = 0;

    for (let i = 0; i < nTrain; i++) {
      let dot = bias;
      for (let j = 0; j < d; j++) {
        dot += weights[j] * XTrain[i][j];
      }
      const p = sigmoid(dot);
      const err = p - yTrain[i]; // equal weights: weight=1 for all classes

      for (let j = 0; j < d; j++) {
        gradW[j] += err * XTrain[i][j];
      }
      gradB += err;
    }

    for (let j = 0; j < d; j++) {
      weights[j] -= (lr * (gradW[j] / nTrain + lambdaL2 * weights[j]));
    }
    bias -= (lr * (gradB / nTrain));
  }

  const trainTimeSeconds = (performance.now() - startTime) / 1000;

  // Inference on testRows
  const nTest = testRows.length;
  const probabilities: number[] = new Array(nTest);
  const predictions: number[] = new Array(nTest);

  let tn = 0, fp = 0, fn = 0, tp = 0;

  for (let i = 0; i < nTest; i++) {
    let dot = bias;
    for (let j = 0; j < d; j++) {
      const valScaled = (testRows[i].features[selectedFeatures[j]] - means[j]) / stds[j];
      dot += weights[j] * valScaled;
    }
    const prob = sigmoid(dot);
    const pred = prob >= 0.5 ? 1 : 0;
    const actual = testRows[i].Target;

    probabilities[i] = Math.round(prob * 10000) / 10000;
    predictions[i] = pred;

    if (actual === 0 && pred === 0) tn++;
    else if (actual === 0 && pred === 1) fp++;
    else if (actual === 1 && pred === 0) fn++;
    else if (actual === 1 && pred === 1) tp++;
  }

  const total = nTest || 1;
  const accuracy = (tp + tn) / total;

  return {
    predictions,
    probabilities,
    accuracy: Math.round(accuracy * 10000) / 10000,
    confusionMatrix: [[tn, fp], [fn, tp]],
    trainTimeSeconds: Math.round(trainTimeSeconds * 1000) / 1000,
  };
}

// 2. Random Forest
interface DecisionTreeNode {
  isLeaf: boolean;
  prediction?: number;
  prob?: number;
  featureIndex?: number;
  threshold?: number;
  left?: DecisionTreeNode;
  right?: DecisionTreeNode;
}

function buildTree(
  X: number[][],
  y: number[],
  indices: number[],
  maxDepth: number,
  minSamplesSplit: number,
  mFeatures: number,
  rng: () => number
): DecisionTreeNode {
  const n = indices.length;
  if (n === 0) return { isLeaf: true, prediction: 0, prob: 0 };

  let count1 = 0;
  for (let i = 0; i < n; i++) {
    if (y[indices[i]] === 1) count1++;
  }
  const prob1 = count1 / n;
  const majorityClass = prob1 >= 0.5 ? 1 : 0;

  if (maxDepth <= 0 || n <= minSamplesSplit || count1 === 0 || count1 === n) {
    return { isLeaf: true, prediction: majorityClass, prob: prob1 };
  }

  const d = X[0].length;
  // Subspace feature selection
  const featureCandidates: number[] = [];
  while (featureCandidates.length < Math.min(mFeatures, d)) {
    const pick = Math.floor(rng() * d);
    if (!featureCandidates.includes(pick)) featureCandidates.push(pick);
  }

  let bestGini = Infinity;
  let bestFeat = -1;
  let bestThresh = 0;
  let bestLeft: number[] = [];
  let bestRight: number[] = [];

  for (const f of featureCandidates) {
    const vals = indices.map(idx => X[idx][f]).sort((a, b) => a - b);
    // Sample potential thresholds
    const numTests = Math.min(10, vals.length - 1);
    const step = Math.max(1, Math.floor(vals.length / (numTests + 1)));

    for (let t = 1; t <= numTests; t++) {
      const idxT = t * step;
      if (idxT >= vals.length) break;
      const thresh = (vals[idxT - 1] + vals[idxT]) / 2;

      let lCount1 = 0, lCount = 0;
      let rCount1 = 0, rCount = 0;

      for (let i = 0; i < n; i++) {
        const rowIdx = indices[i];
        if (X[rowIdx][f] <= thresh) {
          lCount++;
          if (y[rowIdx] === 1) lCount1++;
        } else {
          rCount++;
          if (y[rowIdx] === 1) rCount1++;
        }
      }

      if (lCount === 0 || rCount === 0) continue;

      const pL1 = lCount1 / lCount;
      const giniL = 1 - (pL1 * pL1 + (1 - pL1) * (1 - pL1));

      const pR1 = rCount1 / rCount;
      const giniR = 1 - (pR1 * pR1 + (1 - pR1) * (1 - pR1));

      const weightedGini = (lCount / n) * giniL + (rCount / n) * giniR;

      if (weightedGini < bestGini) {
        bestGini = weightedGini;
        bestFeat = f;
        bestThresh = thresh;
      }
    }
  }

  if (bestFeat === -1) {
    return { isLeaf: true, prediction: majorityClass, prob: prob1 };
  }

  for (let i = 0; i < n; i++) {
    const idx = indices[i];
    if (X[idx][bestFeat] <= bestThresh) bestLeft.push(idx);
    else bestRight.push(idx);
  }

  return {
    isLeaf: false,
    featureIndex: bestFeat,
    threshold: bestThresh,
    left: buildTree(X, y, bestLeft, maxDepth - 1, minSamplesSplit, mFeatures, rng),
    right: buildTree(X, y, bestRight, maxDepth - 1, minSamplesSplit, mFeatures, rng),
  };
}

function predictTree(node: DecisionTreeNode, row: number[]): { pred: number; prob: number } {
  if (node.isLeaf) {
    return { pred: node.prediction ?? 0, prob: node.prob ?? 0 };
  }
  if (row[node.featureIndex!] <= node.threshold!) {
    return predictTree(node.left!, row);
  }
  return predictTree(node.right!, row);
}

export function trainRandomForest(
  trainRows: MLRow[],
  testRows: MLRow[],
  selectedFeatures: string[]
): {
  predictions: number[];
  probabilities: number[];
  accuracy: number;
  confusionMatrix: [[number, number], [number, number]];
  trainTimeSeconds: number;
} {
  const startTime = performance.now();
  const d = selectedFeatures.length;
  const nTrain = trainRows.length;

  const XTrain: number[][] = trainRows.map(r => selectedFeatures.map(f => r.features[f]));
  const yTrain = trainRows.map(r => r.Target);

  const nTrees = 50; // Optimized ensemble size for web runtime
  const mFeatures = Math.max(1, Math.floor(Math.sqrt(d)));
  const trees: DecisionTreeNode[] = [];

  let seed = 42;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  for (let t = 0; t < nTrees; t++) {
    // Bootstrap sampling with equal weights
    const sampleIndices: number[] = new Array(nTrain);
    for (let i = 0; i < nTrain; i++) {
      sampleIndices[i] = Math.floor(rand() * nTrain);
    }

    const tree = buildTree(XTrain, yTrain, sampleIndices, 8, 4, mFeatures, rand);
    trees.push(tree);
  }

  const trainTimeSeconds = (performance.now() - startTime) / 1000;

  // Inference on test
  const nTest = testRows.length;
  const probabilities: number[] = new Array(nTest);
  const predictions: number[] = new Array(nTest);

  let tn = 0, fp = 0, fn = 0, tp = 0;

  for (let i = 0; i < nTest; i++) {
    const row = selectedFeatures.map(f => testRows[i].features[f]);
    let sumProb = 0;

    for (let t = 0; t < nTrees; t++) {
      sumProb += predictTree(trees[t], row).prob;
    }

    const avgProb = sumProb / nTrees;
    const pred = avgProb >= 0.5 ? 1 : 0;
    const actual = testRows[i].Target;

    probabilities[i] = Math.round(avgProb * 10000) / 10000;
    predictions[i] = pred;

    if (actual === 0 && pred === 0) tn++;
    else if (actual === 0 && pred === 1) fp++;
    else if (actual === 1 && pred === 0) fn++;
    else if (actual === 1 && pred === 1) tp++;
  }

  const accuracy = (tp + tn) / (nTest || 1);

  return {
    predictions,
    probabilities,
    accuracy: Math.round(accuracy * 10000) / 10000,
    confusionMatrix: [[tn, fp], [fn, tp]],
    trainTimeSeconds: Math.round(trainTimeSeconds * 1000) / 1000,
  };
}

// 3. XGBoost / Gradient Boosted Decision Trees
interface GBDTNode {
  isLeaf: boolean;
  weight?: number;
  featureIndex?: number;
  threshold?: number;
  left?: GBDTNode;
  right?: GBDTNode;
}

function buildGBDTTree(
  X: number[][],
  gradients: number[],
  hessians: number[],
  indices: number[],
  depth: number,
  maxDepth: number,
  lambdaL2: number
): GBDTNode {
  const n = indices.length;

  let sumG = 0;
  let sumH = 0;
  for (let i = 0; i < n; i++) {
    const idx = indices[i];
    sumG += gradients[idx];
    sumH += hessians[idx];
  }

  // Optimal leaf weight in XGBoost
  const leafWeight = -sumG / (sumH + lambdaL2);

  if (depth >= maxDepth || n <= 4) {
    return { isLeaf: true, weight: leafWeight };
  }

  const d = X[0].length;
  let bestGain = 0;
  let bestFeat = -1;
  let bestThresh = 0;
  let bestLeft: number[] = [];
  let bestRight: number[] = [];

  const rootScore = (sumG * sumG) / (sumH + lambdaL2);

  for (let f = 0; f < d; f++) {
    const vals = indices.map(idx => X[idx][f]).sort((a, b) => a - b);
    const numTests = Math.min(8, vals.length - 1);
    const step = Math.max(1, Math.floor(vals.length / (numTests + 1)));

    for (let t = 1; t <= numTests; t++) {
      const idxT = t * step;
      if (idxT >= vals.length) break;
      const thresh = (vals[idxT - 1] + vals[idxT]) / 2;

      let gL = 0, hL = 0;
      let gR = 0, hR = 0;

      for (let i = 0; i < n; i++) {
        const idx = indices[i];
        if (X[idx][f] <= thresh) {
          gL += gradients[idx];
          hL += hessians[idx];
        } else {
          gR += gradients[idx];
          hR += hessians[idx];
        }
      }

      if (hL === 0 || hR === 0) continue;

      const scoreL = (gL * gL) / (hL + lambdaL2);
      const scoreR = (gR * gR) / (hR + lambdaL2);
      const gain = 0.5 * (scoreL + scoreR - rootScore);

      if (gain > bestGain) {
        bestGain = gain;
        bestFeat = f;
        bestThresh = thresh;
      }
    }
  }

  if (bestFeat === -1 || bestGain <= 0.01) {
    return { isLeaf: true, weight: leafWeight };
  }

  for (let i = 0; i < n; i++) {
    const idx = indices[i];
    if (X[idx][bestFeat] <= bestThresh) bestLeft.push(idx);
    else bestRight.push(idx);
  }

  return {
    isLeaf: false,
    featureIndex: bestFeat,
    threshold: bestThresh,
    left: buildGBDTTree(X, gradients, hessians, bestLeft, depth + 1, maxDepth, lambdaL2),
    right: buildGBDTTree(X, gradients, hessians, bestRight, depth + 1, maxDepth, lambdaL2),
  };
}

function predictGBDTTree(node: GBDTNode, row: number[]): number {
  if (node.isLeaf) return node.weight ?? 0;
  if (row[node.featureIndex!] <= node.threshold!) {
    return predictGBDTTree(node.left!, row);
  }
  return predictGBDTTree(node.right!, row);
}

export function trainXGBoost(
  trainRows: MLRow[],
  testRows: MLRow[],
  selectedFeatures: string[]
): {
  predictions: number[];
  probabilities: number[];
  accuracy: number;
  confusionMatrix: [[number, number], [number, number]];
  trainTimeSeconds: number;
} {
  const startTime = performance.now();
  const nTrain = trainRows.length;
  const XTrain = trainRows.map(r => selectedFeatures.map(f => r.features[f]));
  const yTrain = trainRows.map(r => r.Target);

  const nEstimators = 40;
  const learningRate = 0.05;
  const maxDepth = 5;
  const lambdaL2 = 1.0;

  // Initial base prediction (log odds)
  let count1 = 0;
  for (const y of yTrain) if (y === 1) count1++;
  const baseProb = count1 / nTrain;
  const baseScore = Math.log(Math.max(0.001, baseProb) / Math.max(0.001, 1 - baseProb));

  const trainScores = new Array(nTrain).fill(baseScore);
  const trees: GBDTNode[] = [];

  const allIndices = Array.from({ length: nTrain }, (_, i) => i);

  for (let m = 0; m < nEstimators; m++) {
    const gradients = new Array(nTrain);
    const hessians = new Array(nTrain);

    for (let i = 0; i < nTrain; i++) {
      const p = sigmoid(trainScores[i]);
      // scale_pos_weight = 1 (equal weighting)
      gradients[i] = p - yTrain[i];
      hessians[i] = Math.max(p * (1 - p), 0.0001);
    }

    const tree = buildGBDTTree(XTrain, gradients, hessians, allIndices, 0, maxDepth, lambdaL2);
    trees.push(tree);

    for (let i = 0; i < nTrain; i++) {
      trainScores[i] += learningRate * predictGBDTTree(tree, XTrain[i]);
    }
  }

  const trainTimeSeconds = (performance.now() - startTime) / 1000;

  // Inference on test
  const nTest = testRows.length;
  const probabilities: number[] = new Array(nTest);
  const predictions: number[] = new Array(nTest);

  let tn = 0, fp = 0, fn = 0, tp = 0;

  for (let i = 0; i < nTest; i++) {
    const row = selectedFeatures.map(f => testRows[i].features[f]);
    let score = baseScore;

    for (let m = 0; m < nEstimators; m++) {
      score += learningRate * predictGBDTTree(trees[m], row);
    }

    const prob = sigmoid(score);
    const pred = prob >= 0.5 ? 1 : 0;
    const actual = testRows[i].Target;

    probabilities[i] = Math.round(prob * 10000) / 10000;
    predictions[i] = pred;

    if (actual === 0 && pred === 0) tn++;
    else if (actual === 0 && pred === 1) fp++;
    else if (actual === 1 && pred === 0) fn++;
    else if (actual === 1 && pred === 1) tp++;
  }

  const accuracy = (tp + tn) / (nTest || 1);

  return {
    predictions,
    probabilities,
    accuracy: Math.round(accuracy * 10000) / 10000,
    confusionMatrix: [[tn, fp], [fn, tp]],
    trainTimeSeconds: Math.round(trainTimeSeconds * 1000) / 1000,
  };
}

export function trainModel(
  modelName: string,
  trainRows: MLRow[],
  testRows: MLRow[],
  selectedFeatures: string[]
): {
  predictions: number[];
  probabilities: number[];
  accuracy: number;
  confusionMatrix: [[number, number], [number, number]];
  trainTimeSeconds: number;
} {
  if (modelName === 'Logistic Regression') {
    return trainLogisticRegression(trainRows, testRows, selectedFeatures);
  } else if (modelName === 'Random Forest') {
    return trainRandomForest(trainRows, testRows, selectedFeatures);
  } else if (modelName === 'XGBoost') {
    return trainXGBoost(trainRows, testRows, selectedFeatures);
  }
  throw new Error(`Unsupported model: ${modelName}`);
}

export function createPredictionOutputs(
  testRows: MLRow[],
  predictions: number[],
  probabilities: number[],
  productDescriptions: Map<string, string>
): PredictionOutputRow[] {
  const outputs: PredictionOutputRow[] = testRows.map((r, i) => {
    const desc = r.Description || productDescriptions.get(r.StockCode) || r.StockCode;
    const predMonth = r.NextMonth || addCalendarMonth(r.YearMonth, 1);
    return {
      StockCode: r.StockCode,
      Description: desc,
      PredictionMonth: predMonth,
      Predicted_Best_Seller: predictions[i] ?? 0,
      Prediction_Probability: probabilities[i] ?? 0,
    };
  });

  // Sort by Prediction_Probability descending
  outputs.sort((a, b) => b.Prediction_Probability - a.Prediction_Probability);
  return outputs;
}
