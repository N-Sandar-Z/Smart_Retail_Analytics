import { ProcessedRow, RFMCustomer, KEvalResult, ClusterProfile, RFMAnalysisResult } from '../types';

export const NOTEBOOK_FINAL_K = 2;
export const K_RANGE = [2, 3, 4, 5, 6, 7, 8];

interface Point3D {
  r: number;
  f: number;
  m: number;
}

// Deterministic pseudo-random number generator (seed 42)
function createSeededRandom(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function euclideanDistance(a: Point3D, b: Point3D): number {
  const dr = a.r - b.r;
  const df = a.f - b.f;
  const dm = a.m - b.m;
  return Math.sqrt(dr * dr + df * df + dm * dm);
}

function euclideanDistanceSq(a: Point3D, b: Point3D): number {
  const dr = a.r - b.r;
  const df = a.f - b.f;
  const dm = a.m - b.m;
  return dr * dr + df * df + dm * dm;
}

// K-Means implementation with k-means++ initialization
export function runKMeans(
  data: Point3D[],
  k: number,
  nInit: number = 5,
  maxIter: number = 100,
  randomSeed: number = 42
): { labels: number[]; centroids: Point3D[]; inertia: number } {
  const n = data.length;
  if (n < k) {
    throw new Error(`Cannot cluster ${n} points into ${k} clusters.`);
  }

  const rand = createSeededRandom(randomSeed);
  let bestInertia = Infinity;
  let bestLabels: number[] = new Array(n).fill(0);
  let bestCentroids: Point3D[] = [];

  for (let init = 0; init < nInit; init++) {
    // k-means++ centroid initialization
    const centroids: Point3D[] = [];
    const firstIdx = Math.floor(rand() * n);
    centroids.push({ ...data[firstIdx] });

    while (centroids.length < k) {
      const distSqArr: number[] = new Array(n);
      let sumDistSq = 0;

      for (let i = 0; i < n; i++) {
        let minDistSq = Infinity;
        for (let c = 0; c < centroids.length; c++) {
          const dSq = euclideanDistanceSq(data[i], centroids[c]);
          if (dSq < minDistSq) minDistSq = dSq;
        }
        distSqArr[i] = minDistSq;
        sumDistSq += minDistSq;
      }

      if (sumDistSq === 0) {
        // All points duplicate
        centroids.push({ ...data[Math.floor(rand() * n)] });
        continue;
      }

      const threshold = rand() * sumDistSq;
      let cum = 0;
      let selected = n - 1;
      for (let i = 0; i < n; i++) {
        cum += distSqArr[i];
        if (cum >= threshold) {
          selected = i;
          break;
        }
      }
      centroids.push({ ...data[selected] });
    }

    const labels: number[] = new Array(n).fill(0);
    let changed = true;
    let iter = 0;

    while (changed && iter < maxIter) {
      changed = false;
      iter++;

      // Assignment step
      for (let i = 0; i < n; i++) {
        let minDistSq = Infinity;
        let closest = 0;
        for (let c = 0; c < k; c++) {
          const dSq = euclideanDistanceSq(data[i], centroids[c]);
          if (dSq < minDistSq) {
            minDistSq = dSq;
            closest = c;
          }
        }
        if (labels[i] !== closest) {
          labels[i] = closest;
          changed = true;
        }
      }

      // Update centroids
      const counts = new Array(k).fill(0);
      const sums: Point3D[] = Array.from({ length: k }, () => ({ r: 0, f: 0, m: 0 }));

      for (let i = 0; i < n; i++) {
        const cl = labels[i];
        counts[cl]++;
        sums[cl].r += data[i].r;
        sums[cl].f += data[i].f;
        sums[cl].m += data[i].m;
      }

      for (let c = 0; c < k; c++) {
        if (counts[c] > 0) {
          centroids[c].r = sums[c].r / counts[c];
          centroids[c].f = sums[c].f / counts[c];
          centroids[c].m = sums[c].m / counts[c];
        } else {
          // Reassign empty cluster to random point
          centroids[c] = { ...data[Math.floor(rand() * n)] };
        }
      }
    }

    // Compute inertia
    let currentInertia = 0;
    for (let i = 0; i < n; i++) {
      currentInertia += euclideanDistanceSq(data[i], centroids[labels[i]]);
    }

    if (currentInertia < bestInertia) {
      bestInertia = currentInertia;
      bestLabels = [...labels];
      bestCentroids = centroids.map(c => ({ ...c }));
    }
  }

  return { labels: bestLabels, centroids: bestCentroids, inertia: bestInertia };
}

// Compute Silhouette Score
export function calculateSilhouetteScore(data: Point3D[], labels: number[], k: number): number {
  const n = data.length;
  if (n <= k || k < 2) return 0;

  // Sample points if n is very large for performance (> 2000 points)
  let sampleIndices: number[];
  if (n > 2000) {
    const step = Math.ceil(n / 2000);
    sampleIndices = [];
    for (let i = 0; i < n; i += step) {
      sampleIndices.push(i);
    }
  } else {
    sampleIndices = Array.from({ length: n }, (_, i) => i);
  }

  const sampleSize = sampleIndices.length;
  let totalSilhouette = 0;

  for (let s = 0; s < sampleSize; s++) {
    const i = sampleIndices[s];
    const point = data[i];
    const clusterI = labels[i];

    // Compute a(i): average distance to points in same cluster
    // Compute cluster-wise average distances for all clusters
    const clusterDistSums = new Array(k).fill(0);
    const clusterCounts = new Array(k).fill(0);

    for (let j = 0; j < n; j++) {
      if (i === j) continue;
      const cl = labels[j];
      const dist = euclideanDistance(point, data[j]);
      clusterDistSums[cl] += dist;
      clusterCounts[cl]++;
    }

    let a_i = 0;
    if (clusterCounts[clusterI] > 0) {
      a_i = clusterDistSums[clusterI] / clusterCounts[clusterI];
    }

    let b_i = Infinity;
    for (let c = 0; c < k; c++) {
      if (c === clusterI) continue;
      if (clusterCounts[c] > 0) {
        const avgDist = clusterDistSums[c] / clusterCounts[c];
        if (avgDist < b_i) {
          b_i = avgDist;
        }
      }
    }

    const max_ab = Math.max(a_i, b_i);
    const s_i = max_ab > 0 ? (b_i - a_i) / max_ab : 0;
    totalSilhouette += s_i;
  }

  return totalSilhouette / sampleSize;
}

export function buildRFMAnalysis(
  customerRows: ProcessedRow[],
  finalKRequested: number = NOTEBOOK_FINAL_K
): RFMAnalysisResult {
  if (customerRows.length === 0) {
    throw new Error('Customer analysis dataset is empty.');
  }

  // 1. Snapshot date: maximum InvoiceDate + 1 day
  let maxDate = new Date(-8640000000000000);
  for (const row of customerRows) {
    if (row.InvoiceDate > maxDate) {
      maxDate = row.InvoiceDate;
    }
  }
  const snapshotDate = new Date(maxDate.getTime() + 24 * 60 * 60 * 1000);

  // Group by CustomerID
  const custMap = new Map<string, { lastDate: Date; invoices: Set<string>; revenue: number }>();

  for (const row of customerRows) {
    let entry = custMap.get(row.CustomerID);
    if (!entry) {
      entry = { lastDate: row.InvoiceDate, invoices: new Set(), revenue: 0 };
      custMap.set(row.CustomerID, entry);
    }
    if (row.InvoiceDate > entry.lastDate) {
      entry.lastDate = row.InvoiceDate;
    }
    entry.invoices.add(row.InvoiceNo);
    entry.revenue += row.Revenue;
  }

  const rfm: RFMCustomer[] = [];
  const MS_PER_DAY = 1000 * 60 * 60 * 24;

  for (const [CustomerID, data] of custMap.entries()) {
    const recencyDays = Math.floor((snapshotDate.getTime() - data.lastDate.getTime()) / MS_PER_DAY);
    rfm.push({
      CustomerID,
      Recency: Math.max(0, recencyDays),
      Frequency: data.invoices.size,
      Monetary: Math.round(data.revenue * 100) / 100,
    });
  }

  if (rfm.length < 2) {
    throw new Error(`Insufficient customer records (${rfm.length}) for segmentation.`);
  }

  // 2. StandardScaler: (x - mean) / std
  const n = rfm.length;
  let sumR = 0, sumF = 0, sumM = 0;
  for (const c of rfm) {
    sumR += c.Recency;
    sumF += c.Frequency;
    sumM += c.Monetary;
  }
  const meanR = sumR / n;
  const meanF = sumF / n;
  const meanM = sumM / n;

  let varR = 0, varF = 0, varM = 0;
  for (const c of rfm) {
    varR += (c.Recency - meanR) ** 2;
    varF += (c.Frequency - meanF) ** 2;
    varM += (c.Monetary - meanM) ** 2;
  }
  const stdR = Math.sqrt(varR / n) || 1;
  const stdF = Math.sqrt(varF / n) || 1;
  const stdM = Math.sqrt(varM / n) || 1;

  const rfmScaled: Point3D[] = rfm.map(c => ({
    r: (c.Recency - meanR) / stdR,
    f: (c.Frequency - meanF) / stdF,
    m: (c.Monetary - meanM) / stdM,
  }));

  // 3. Evaluate K from 2 to 8
  const kEval: KEvalResult[] = [];
  let bestSilhouette = -Infinity;
  let recommendedK = 2;

  const validKRange = K_RANGE.filter(k => k <= n);
  for (const k of validKRange) {
    const km = runKMeans(rfmScaled, k, 5, 80, 42);
    const sil = calculateSilhouetteScore(rfmScaled, km.labels, k);
    kEval.push({
      K: k,
      Inertia: Math.round(km.inertia * 100) / 100,
      Silhouette: Math.round(sil * 10000) / 10000,
    });
    if (sil > bestSilhouette) {
      bestSilhouette = sil;
      recommendedK = k;
    }
  }

  // 4. Project Final K logic (Notebook explicitly uses FINAL_K = 2)
  let finalK = Math.min(Math.max(finalKRequested, 2), n);

  const finalKm = runKMeans(rfmScaled, finalK, 10, 100, 42);
  for (let i = 0; i < n; i++) {
    rfm[i].Cluster = finalKm.labels[i];
  }

  // 5. Cluster Profile
  const clusterCounts = new Array(finalK).fill(0);
  const clusterSums: { r: number; f: number; m: number }[] = Array.from({ length: finalK }, () => ({ r: 0, f: 0, m: 0 }));

  for (let i = 0; i < n; i++) {
    const cl = rfm[i].Cluster!;
    clusterCounts[cl]++;
    clusterSums[cl].r += rfm[i].Recency;
    clusterSums[cl].f += rfm[i].Frequency;
    clusterSums[cl].m += rfm[i].Monetary;
  }

  const rawProfiles: {
    Cluster: number;
    Customer_Count: number;
    Customer_Percentage: number;
    Avg_Recency: number;
    Avg_Frequency: number;
    Avg_Monetary: number;
  }[] = [];

  for (let c = 0; c < finalK; c++) {
    const count = clusterCounts[c] || 1;
    rawProfiles.push({
      Cluster: c,
      Customer_Count: clusterCounts[c],
      Customer_Percentage: Math.round((clusterCounts[c] / n) * 10000) / 100,
      Avg_Recency: Math.round((clusterSums[c].r / count) * 100) / 100,
      Avg_Frequency: Math.round((clusterSums[c].f / count) * 100) / 100,
      Avg_Monetary: Math.round((clusterSums[c].m / count) * 100) / 100,
    });
  }

  // Median values across clusters
  const recMed = getMedian(rawProfiles.map(p => p.Avg_Recency));
  const freqMed = getMedian(rawProfiles.map(p => p.Avg_Frequency));
  const monMed = getMedian(rawProfiles.map(p => p.Avg_Monetary));

  // Compute ranks for RFM_Score
  // RFM_Score = -rank(Avg_Recency, asc=True) + rank(Avg_Frequency, asc=True) + rank(Avg_Monetary, asc=True)
  const recRanks = computeRank(rawProfiles.map(p => p.Avg_Recency), true);
  const freqRanks = computeRank(rawProfiles.map(p => p.Avg_Frequency), true);
  const monRanks = computeRank(rawProfiles.map(p => p.Avg_Monetary), true);

  const clusterProfilesWithScore = rawProfiles.map((p, idx) => {
    const rScore = -recRanks[idx] + freqRanks[idx] + monRanks[idx];
    const characteristics = [
      p.Avg_Recency <= recMed ? 'Recent buyers' : 'Less recent buyers',
      p.Avg_Frequency >= freqMed ? 'Frequent buyers' : 'Less frequent buyers',
      p.Avg_Monetary >= monMed ? 'High spending' : 'Lower spending',
    ].join(', ');

    return {
      ...p,
      Characteristics: characteristics,
      RFM_Score: rScore,
      Segment: '',
      BusinessAction: '',
    };
  });

  // Sort clusters descending by RFM_Score
  const sortedIndices = clusterProfilesWithScore
    .map((p, idx) => ({ idx, score: p.RFM_Score }))
    .sort((a, b) => b.score - a.score)
    .map(x => x.idx);

  const segmentMap: Record<number, string> = {};
  if (sortedIndices.length >= 1) {
    segmentMap[sortedIndices[0]] = 'VIP / High-Value';
  }
  if (sortedIndices.length >= 2) {
    segmentMap[sortedIndices[1]] = 'Regular / Normal';
  }
  for (let s = 2; s < sortedIndices.length; s++) {
    segmentMap[sortedIndices[s]] = 'Low-Value / At-Risk';
  }

  const businessActions: Record<string, string> = {
    'VIP / High-Value': 'Provide loyalty rewards, exclusive offers, and personalized promotions.',
    'Regular / Normal': 'Use cross-selling, bundle offers, and loyalty campaigns.',
    'Low-Value / At-Risk': 'Use re-engagement campaigns, discounts, and targeted promotions.',
  };

  const finalClusterProfile: ClusterProfile[] = clusterProfilesWithScore.map((p, idx) => {
    const segment = segmentMap[idx] || 'Low-Value / At-Risk';
    return {
      ...p,
      Segment: segment,
      BusinessAction: businessActions[segment],
    };
  });

  // Assign segment to each customer in rfm
  for (const c of rfm) {
    if (c.Cluster !== undefined) {
      c.Segment = finalClusterProfile[c.Cluster]?.Segment || 'Unclassified';
    }
  }

  return {
    rfm,
    kEval,
    recommendedK,
    finalK,
    clusterProfile: finalClusterProfile,
  };
}

function getMedian(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function computeRank(values: number[], ascending: boolean = true): number[] {
  const indexed = values.map((val, i) => ({ val, i }));
  indexed.sort((a, b) => ascending ? a.val - b.val : b.val - a.val);

  const ranks = new Array(values.length).fill(0);
  for (let r = 0; r < indexed.length; r++) {
    ranks[indexed[r].i] = r + 1; // 1-based rank
  }
  return ranks;
}
