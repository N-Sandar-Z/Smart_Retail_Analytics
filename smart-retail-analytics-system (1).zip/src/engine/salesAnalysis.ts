import { ProcessedRow } from '../types';

export interface MonthlySalesData {
  YearMonth: string;
  Revenue: number;
}

export interface YearlySalesData {
  Year: string;
  Revenue: number;
}

export interface CategoryMetric {
  name: string;
  value: number;
}

export interface TransactionSummaryItem {
  InvoiceNo: string;
  Revenue: number;
  Quantity: number;
  UniqueProducts: number;
  CustomerID: string;
}

export interface SalesAnalysisResult {
  monthlySales: MonthlySalesData[];
  yearlySales: YearlySalesData[];
  topCountries: CategoryMetric[];
  topProductsQuantity: CategoryMetric[];
  topProductsRevenue: CategoryMetric[];
  validTransactionsCount: number;
  averageOrderValue: number;
  sampleTransactions: TransactionSummaryItem[];
}

export function computeSalesAnalysis(salesRows: ProcessedRow[]): SalesAnalysisResult {
  if (salesRows.length === 0) {
    return {
      monthlySales: [],
      yearlySales: [],
      topCountries: [],
      topProductsQuantity: [],
      topProductsRevenue: [],
      validTransactionsCount: 0,
      averageOrderValue: 0,
      sampleTransactions: [],
    };
  }

  // Monthly revenue
  const monthlyMap = new Map<string, number>();
  // Yearly revenue
  const yearlyMap = new Map<string, number>();
  // Country revenue
  const countryMap = new Map<string, number>();
  // Product quantity & revenue
  const productQtyMap = new Map<string, number>();
  const productRevMap = new Map<string, number>();

  // Transactions aggregation
  const transMap = new Map<string, { Revenue: number; Quantity: number; products: Set<string>; CustomerID: string }>();

  for (const row of salesRows) {
    // Monthly
    monthlyMap.set(row.YearMonth, (monthlyMap.get(row.YearMonth) || 0) + row.Revenue);
    // Yearly
    const yr = String(row.Year);
    yearlyMap.set(yr, (yearlyMap.get(yr) || 0) + row.Revenue);
    // Country
    countryMap.set(row.Country, (countryMap.get(row.Country) || 0) + row.Revenue);
    // Product
    const desc = row.Description || row.StockCode || 'Unknown Product';
    productQtyMap.set(desc, (productQtyMap.get(desc) || 0) + row.Quantity);
    productRevMap.set(desc, (productRevMap.get(desc) || 0) + row.Revenue);

    // Transaction
    let t = transMap.get(row.InvoiceNo);
    if (!t) {
      t = { Revenue: 0, Quantity: 0, products: new Set<string>(), CustomerID: row.CustomerID };
      transMap.set(row.InvoiceNo, t);
    }
    t.Revenue += row.Revenue;
    t.Quantity += row.Quantity;
    t.products.add(row.StockCode);
    if (!t.CustomerID && row.CustomerID) {
      t.CustomerID = row.CustomerID;
    }
  }

  // Sort monthly
  const monthlySales: MonthlySalesData[] = Array.from(monthlyMap.entries())
    .map(([YearMonth, Revenue]) => ({ YearMonth, Revenue: Math.round(Revenue * 100) / 100 }))
    .sort((a, b) => a.YearMonth.localeCompare(b.YearMonth));

  // Sort yearly
  const yearlySales: YearlySalesData[] = Array.from(yearlyMap.entries())
    .map(([Year, Revenue]) => ({ Year, Revenue: Math.round(Revenue * 100) / 100 }))
    .sort((a, b) => a.Year.localeCompare(b.Year));

  // Top 15 countries
  const topCountries: CategoryMetric[] = Array.from(countryMap.entries())
    .map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 15);

  // Top 15 products by quantity
  const topProductsQuantity: CategoryMetric[] = Array.from(productQtyMap.entries())
    .map(([name, value]) => ({ name, value: Math.round(value) }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 15);

  // Top 15 products by revenue
  const topProductsRevenue: CategoryMetric[] = Array.from(productRevMap.entries())
    .map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 15);

  const totalTransCount = transMap.size;
  let totalTransRev = 0;
  const sampleTransactions: TransactionSummaryItem[] = [];

  let count = 0;
  for (const [InvoiceNo, data] of transMap.entries()) {
    totalTransRev += data.Revenue;
    if (count < 50) {
      sampleTransactions.push({
        InvoiceNo,
        Revenue: Math.round(data.Revenue * 100) / 100,
        Quantity: data.Quantity,
        UniqueProducts: data.products.size,
        CustomerID: data.CustomerID,
      });
      count++;
    }
  }

  const averageOrderValue = totalTransCount > 0 ? Math.round((totalTransRev / totalTransCount) * 100) / 100 : 0;

  return {
    monthlySales,
    yearlySales,
    topCountries,
    topProductsQuantity,
    topProductsRevenue,
    validTransactionsCount: totalTransCount,
    averageOrderValue,
    sampleTransactions,
  };
}
