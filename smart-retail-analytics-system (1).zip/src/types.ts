export interface RawRetailRow {
  InvoiceNo: string;
  StockCode: string;
  Description: string;
  Quantity: number;
  InvoiceDate: string;
  UnitPrice: number;
  CustomerID?: string;
  Country: string;
}

export interface ProcessedRow {
  InvoiceNo: string;
  StockCode: string;
  Description: string;
  Quantity: number;
  InvoiceDate: Date;
  UnitPrice: number;
  CustomerID: string;
  Country: string;
  Year: number;
  Month: number;
  YearMonth: string; // YYYY-MM
  Day: number;
  DayOfWeek: number;
  DayName: string;
  Hour: number;
  IsWeekend: boolean;
  Revenue: number;
}

export interface DataQualityMetrics {
  rawRows: number;
  salesRows: number;
  uniqueCustomers: number;
  validTransactions: number;
  totalRevenue: number;
  dateRange: { start: string; end: string };
  missingCustomerRows: number;
  cancelledRows: number;
  duplicateRows: number;
  invalidDates: number;
}

export interface PreparedData {
  rawRows: RawRetailRow[];
  salesRows: ProcessedRow[];
  customerRows: ProcessedRow[];
  basketRows: ProcessedRow[];
  quality: DataQualityMetrics;
}

export interface RFMCustomer {
  CustomerID: string;
  Recency: number;
  Frequency: number;
  Monetary: number;
  Cluster?: number;
  Segment?: string;
}

export interface KEvalResult {
  K: number;
  Inertia: number;
  Silhouette: number;
}

export interface ClusterProfile {
  Cluster: number;
  Customer_Count: number;
  Customer_Percentage: number;
  Avg_Recency: number;
  Avg_Frequency: number;
  Avg_Monetary: number;
  Characteristics: string;
  Segment: string;
  BusinessAction: string;
  RFM_Score: number;
}

export interface RFMAnalysisResult {
  rfm: RFMCustomer[];
  kEval: KEvalResult[];
  recommendedK: number;
  finalK: number;
  clusterProfile: ClusterProfile[];
}

export interface AssociationRule {
  antecedents: string[];
  consequents: string[];
  Antecedent: string;
  Consequent: string;
  support: number;
  confidence: number;
  lift: number;
  YearMonth?: string;
}

export interface AssociationAnalysisResult {
  comparison: {
    Algorithm: string;
    executionTimeSeconds: number;
    frequentItemsetsCount: number;
    rulesCount: number;
  }[];
  aprioriRules: AssociationRule[];
  fpRules: AssociationRule[];
  filteredRules: AssociationRule[];
  basketTransactionsCount: number;
  distinctProductsCount: number;
}

export interface TemporalAssociationResult {
  executionTimeSeconds: number;
  monthlyRuleCounts: { YearMonth: string; count: number }[];
  rules: AssociationRule[];
}

export interface MLModelResult {
  modelName: string;
  accuracy: number;
  trainTimeSeconds: number;
  selectedColumns: string[];
  featureScores: { Feature: string; Score: number; Selected: boolean }[];
  confusionMatrix: [[number, number], [number, number]]; // [[TN, FP], [FN, TP]]
  testSingleClass: boolean;
  predictionsCount: number;
  predictedBestSellerCount: number;
}

export interface PredictionOutputRow {
  StockCode: string;
  Description: string;
  PredictionMonth: string;
  Predicted_Best_Seller: number; // 0 or 1
  Prediction_Probability: number; // 0.0 to 1.0
}

export interface PredictiveAnalysisState {
  trainRowsCount: number;
  testRowsCount: number;
  trainPeriod: { start: string; end: string };
  testPeriod: { start: string; end: string };
  trainClassDist: { Target: number; Count: number; Percentage: number }[];
  featureCount: number;
  results: Record<string, MLModelResult>;
  activeModel: string;
  predictions: PredictionOutputRow[];
}
